<?php
// seed.php - Jalankan sekali untuk membuat data dummy
require_once 'config/database.php';

// Hapus data lama
$pdo->exec("DELETE FROM aktivitas");
$pdo->exec("DELETE FROM rating");
$pdo->exec("DELETE FROM titipan");
$pdo->exec("DELETE FROM users");
$pdo->exec("ALTER TABLE users AUTO_INCREMENT = 1");

// Data dummy
$users = [
    ['admin', 'Administrator', 'ADMIN001', 'admin@titipin.com', 'admin123', '081234567890', 'Manajemen', 'A', 'default.jpg', 'admin'],
    ['20230001', 'Aditya', '20230001', 'aditya@titipin.com', 'mahasiswa123', '081234567891', 'Teknik Informatika', 'TI-3A', 'default.jpg', 'mahasiswa'],
    ['20230002', 'Ardianto', '20230002', 'ardianto@titipin.com', 'mahasiswa123', '081234567892', 'Sistem Informasi', 'SI-3B', 'default.jpg', 'mahasiswa'],
    ['20230003', 'Rifky', '20230003', 'rifky@titipin.com', 'mahasiswa123', '081234567893', 'Manajemen', 'M-3A', 'default.jpg', 'mahasiswa']
];

$stmt = $pdo->prepare("INSERT INTO users (npm, nama, email, password, no_hp, prodi, kelas, foto, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

foreach ($users as $u) {
    $hash = password_hash($u[4], PASSWORD_DEFAULT);
    $stmt->execute([$u[0], $u[1], $u[2], $hash, $u[5], $u[6], $u[7], $u[8], $u[9]]);
}

echo "✅ Data dummy berhasil ditambahkan!<br>";
echo "Admin: admin@titipin.com / admin123<br>";
echo "Mahasiswa: aditya@titipin.com / mahasiswa123<br>";
echo "<a href='index.php'>Ke Beranda</a>";
?>