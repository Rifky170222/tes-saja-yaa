<?php
require_once '../config/database.php';
cekLogin();
cekRole('admin');

// Handle tambah/edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $nama = trim($_POST['nama_kategori'] ?? '');
    
    if (!empty($nama)) {
        if ($id > 0) {
            $stmt = $pdo->prepare("UPDATE kategori SET nama_kategori = ? WHERE id = ?");
            $stmt->execute([$nama, $id]);
            logAktivitas($pdo, $_SESSION['user_id'], null, "Mengupdate kategori: $nama");
        } else {
            $stmt = $pdo->prepare("INSERT INTO kategori (nama_kategori) VALUES (?)");
            $stmt->execute([$nama]);
            logAktivitas($pdo, $_SESSION['user_id'], null, "Menambah kategori: $nama");
        }
        header('Location: kategori.php');
        exit;
    }
}

// Handle hapus
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM titipan WHERE kategori_id = ?");
    $stmt->execute([$id]);
    
    if ($stmt->fetchColumn() == 0) {
        $stmt = $pdo->prepare("DELETE FROM kategori WHERE id = ?");
        $stmt->execute([$id]);
        $_SESSION['success'] = 'Kategori berhasil dihapus.';
    } else {
        $_SESSION['error'] = 'Kategori tidak bisa dihapus karena sedang digunakan.';
    }
    header('Location: kategori.php');
    exit;
}

// Edit data
$edit = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM kategori WHERE id = ?");
    $stmt->execute([$id]);
    $edit = $stmt->fetch();
}

$kategoris = $pdo->query("SELECT k.*, (SELECT COUNT(*) FROM titipan WHERE kategori_id = k.id) as total_titipan 
                          FROM kategori k ORDER BY k.nama_kategori")->fetchAll();

$icons = ['bi-file-earmark-text', 'bi-cup-hot', 'bi-bag', 'bi-phone', 'bi-book', 'bi-pencil-square', 'bi-box'];
$colors = ['#0d6efd', '#fd7e14', '#d63384', '#6f42c1', '#20c997', '#ffc107', '#0dcaf0'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kategori - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .page-header {
            background: linear-gradient(135deg, #20c997 0%, #0dcaf0 100%);
            border-radius: 24px;
            padding: 2rem;
            color: white;
            margin-bottom: 1.5rem;
            position: relative;
            overflow: hidden;
        }
        .page-header::before {
            content: '';
            position: absolute;
            top: -50%; right: -10%;
            width: 300px; height: 300px;
            background: radial-gradient(circle, rgba(255,255,255,0.15), transparent 70%);
            border-radius: 50%;
        }
        .category-card {
            background: white;
            border-radius: 20px;
            padding: 1.5rem;
            border: 1px solid rgba(0,0,0,0.04);
            box-shadow: var(--shadow-sm);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            height: 100%;
        }
        .category-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: var(--cat-color);
            transform: scaleX(0);
            transition: transform 0.4s;
        }
        .category-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-lg);
        }
        .category-card:hover::before {
            transform: scaleX(1);
        }
        .category-icon {
            width: 64px; height: 64px;
            border-radius: 18px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.8rem;
            color: white;
            background: var(--cat-color);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
            transition: transform 0.3s;
            margin-bottom: 1rem;
        }
        .category-card:hover .category-icon {
            transform: scale(1.1) rotate(5deg);
        }
        .category-name {
            font-size: 1.1rem;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 0.3rem;
        }
        .category-count {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 12px;
            border-radius: 20px;
            background: rgba(0,0,0,0.05);
            font-size: 0.8rem;
            font-weight: 600;
            color: #495057;
        }
        .form-card {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            border: 1px solid rgba(0,0,0,0.04);
            box-shadow: var(--shadow-sm);
            position: sticky;
            top: 90px;
        }
        .form-card-header {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px dashed #e9ecef;
        }
        .form-card-icon {
            width: 48px; height: 48px;
            border-radius: 12px;
            background: linear-gradient(135deg, #20c997, #0dcaf0);
            color: white;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.3rem;
        }
        .input-modern {
            padding: 12px 16px;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            width: 100%;
            font-size: 0.9rem;
            transition: all 0.3s;
        }
        .input-modern:focus {
            border-color: #20c997;
            box-shadow: 0 0 0 4px rgba(32, 201, 151, 0.1);
            outline: none;
        }
        .btn-submit {
            background: linear-gradient(135deg, #20c997, #0dcaf0);
            border: none;
            color: white;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 600;
            width: 100%;
            box-shadow: 0 5px 15px rgba(32, 201, 151, 0.3);
            transition: all 0.3s;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(32, 201, 151, 0.4);
            color: white;
        }
        .action-btn {
            width: 36px; height: 36px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center; justify-content: center;
            border: none;
            transition: all 0.3s;
            text-decoration: none;
        }
        .action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }
        .btn-edit { background: rgba(13, 110, 253, 0.1); color: #0d6efd; }
        .btn-delete { background: rgba(220, 53, 69, 0.1); color: #dc3545; }
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
        }
        .empty-state-icon {
            width: 120px; height: 120px;
            margin: 0 auto 1.5rem;
            background: linear-gradient(135deg, rgba(32,201,151,0.1), rgba(13,202,240,0.1));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            animation: bounce 2s infinite;
        }
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        .fade-in-card {
            animation: fadeInCard 0.5s ease-out backwards;
        }
        @keyframes fadeInCard {
            from { opacity: 0; transform: translateY(20px) scale(0.95); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }
    </style>
</head>
<body>
    <div class="bg-blobs">
        <div class="blob blob-1"></div>
        <div class="blob blob-2"></div>
        <div class="blob blob-3"></div>
    </div>

    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <div class="topbar-modern">
            <button class="topbar-icon-btn d-lg-none me-2" id="sidebarToggle">
                <i class="bi bi-list"></i>
            </button>
            <div class="topbar-search d-none d-md-block">
                <i class="bi bi-search"></i>
                <input type="text" placeholder="Cari kategori...">
            </div>
            <div class="topbar-actions">
                <div class="dropdown">
                    <div class="topbar-user" data-bs-toggle="dropdown">
                        <img src="../assets/img/<?= htmlspecialchars($_SESSION['foto'] ?? 'default.jpg') ?>" alt="Admin">
                        <div class="topbar-user-info d-none d-md-block">
                            <h6><?= htmlspecialchars($_SESSION['nama']) ?></h6>
                            <small>Administrator</small>
                        </div>
                        <i class="bi bi-chevron-down small text-muted"></i>
                    </div>
                    <div class="dropdown-menu dropdown-menu-end dropdown-menu-modern">
                        <a href="../logout.php" class="dropdown-item-modern text-danger">
                            <i class="bi bi-box-arrow-right"></i>
                            <div><div class="fw-semibold small">Logout</div></div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="content-wrapper">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" style="border-radius: 12px; border: none;">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= htmlspecialchars($_SESSION['success']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" style="border-radius: 12px; border: none;">
                    <i class="bi bi-exclamation-circle-fill me-2"></i> <?= htmlspecialchars($_SESSION['error']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <!-- Page Header -->
            <div class="page-header fade-in-up">
                <div class="row align-items-center position-relative" style="z-index: 2;">
                    <div class="col-md-8">
                        <small class="opacity-75"><i class="bi bi-tags-fill me-1"></i> Klasifikasi Barang</small>
                        <h2 class="fw-bold mt-1 mb-2">Kategori Barang</h2>
                        <p class="mb-0 opacity-90">Kelola kategori untuk mengklasifikasikan jenis barang titipan</p>
                    </div>
                    <div class="col-md-4 text-md-end mt-3 mt-md-0">
                        <div class="d-inline-flex gap-2">
                            <div class="bg-white bg-opacity-25 rounded-3 px-3 py-2">
                                <small class="d-block opacity-75">Total Kategori</small>
                                <h4 class="mb-0 fw-bold"><?= count($kategoris) ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <!-- Form Column -->
                <div class="col-lg-4 fade-in-up stagger-1">
                    <div class="form-card">
                        <div class="form-card-header">
                            <div class="form-card-icon">
                                <i class="bi bi-<?= $edit ? 'pencil-fill' : 'plus-lg' ?>"></i>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-0"><?= $edit ? 'Edit Kategori' : 'Tambah Kategori Baru' ?></h6>
                                <small class="text-muted"><?= $edit ? 'Perbarui nama kategori' : 'Buat kategori baru untuk barang' ?></small>
                            </div>
                        </div>

                        <form method="POST">
                            <input type="hidden" name="id" value="<?= $edit['id'] ?? 0 ?>">
                            <div class="mb-3">
                                <label class="form-label small fw-semibold">
                                    <i class="bi bi-tag text-primary"></i> Nama Kategori
                                </label>
                                <input type="text" name="nama_kategori" class="input-modern" 
                                       placeholder="Contoh: Dokumen, Makanan, dll"
                                       value="<?= htmlspecialchars($edit['nama_kategori'] ?? '') ?>" required>
                            </div>
                            <button type="submit" class="btn btn-submit">
                                <i class="bi bi-<?= $edit ? 'check-circle' : 'plus-circle' ?> me-1"></i>
                                <?= $edit ? 'Update Kategori' : 'Tambah Kategori' ?>
                            </button>
                            <?php if ($edit): ?>
                                <a href="kategori.php" class="btn btn-light w-100 mt-2" style="border-radius: 12px;">
                                    <i class="bi bi-x-circle me-1"></i> Batal
                                </a>
                            <?php endif; ?>
                        </form>

                        <div class="mt-4 p-3 rounded-3" style="background: linear-gradient(135deg, rgba(32,201,151,0.05), rgba(13,202,240,0.05));">
                            <small class="text-muted d-block mb-2">
                                <i class="bi bi-info-circle text-primary"></i> Tips
                            </small>
                            <small class="text-muted">
                                Kategori membantu mahasiswa menemukan titipan dengan lebih mudah berdasarkan jenis barang.
                            </small>
                        </div>
                    </div>
                </div>

                <!-- Categories Grid -->
                <div class="col-lg-8">
                    <?php if (empty($kategoris)): ?>
                        <div class="modern-card">
                            <div class="empty-state">
                                <div class="empty-state-icon">
                                    <i class="bi bi-tags" style="font-size: 3rem; color: #20c997;"></i>
                                </div>
                                <h5 class="fw-bold">Belum ada kategori</h5>
                                <p class="text-muted">Mulai tambahkan kategori pertama Anda</p>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="row g-3">
                            <?php foreach ($kategoris as $i => $k): 
                                $color = $colors[$i % count($colors)];
                                $icon = $icons[$i % count($icons)];
                            ?>
                                <div class="col-md-6" style="animation-delay: <?= $i * 0.1 ?>s;">
                                    <div class="category-card fade-in-card" style="--cat-color: <?= $color ?>;">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <div class="category-icon">
                                                <i class="bi bi-<?= $icon ?>"></i>
                                            </div>
                                            <div class="dropdown">
                                                <button class="btn btn-light btn-sm" data-bs-toggle="dropdown" style="border-radius: 8px;">
                                                    <i class="bi bi-three-dots-vertical"></i>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end" style="border-radius: 12px; border: none; box-shadow: var(--shadow-md);">
                                                    <li>
                                                        <a class="dropdown-item" href="?edit=<?= $k['id'] ?>" style="border-radius: 8px;">
                                                            <i class="bi bi-pencil text-primary me-2"></i> Edit
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item text-danger" href="?hapus=<?= $k['id'] ?>" 
                                                           onclick="return confirm('Hapus kategori ini?')" style="border-radius: 8px;">
                                                            <i class="bi bi-trash me-2"></i> Hapus
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <h6 class="category-name"><?= htmlspecialchars($k['nama_kategori']) ?></h6>
                                        <div class="d-flex justify-content-between align-items-center mt-3">
                                            <span class="category-count">
                                                <i class="bi bi-box-seam"></i>
                                                <?= $k['total_titipan'] ?> titipan
                                            </span>
                                            <small class="text-muted">
                                                <i class="bi bi-calendar3"></i>
                                                <?= date('d M Y', strtotime($k['created_at'])) ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('sidebarToggle')?.addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
        });
    </script>
</body>
</html>