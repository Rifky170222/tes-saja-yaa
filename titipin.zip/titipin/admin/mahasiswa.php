<?php
require_once '../config/database.php';
cekLogin();
cekRole('admin');

// Handle delete
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    if ($id != $_SESSION['user_id']) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'mahasiswa'");
        $stmt->execute([$id]);
        logAktivitas($pdo, $_SESSION['user_id'], null, "Menghapus mahasiswa ID $id");
        $_SESSION['success'] = 'Mahasiswa berhasil dihapus.';
    }
    header('Location: mahasiswa.php');
    exit;
}

$search = trim($_GET['search'] ?? '');
$prodi_filter = trim($_GET['prodi'] ?? '');
$sort = $_GET['sort'] ?? 'terbaru';

$where = "role = 'mahasiswa'";
$params = [];

if (!empty($search)) {
    $where .= " AND (nama LIKE ? OR npm LIKE ? OR email LIKE ?)";
    $params = array_merge($params, ["%$search%", "%$search%", "%$search%"]);
}
if (!empty($prodi_filter)) {
    $where .= " AND prodi LIKE ?";
    $params[] = "%$prodi_filter%";
}

$order = match($sort) {
    'nama' => 'nama ASC',
    'rating' => 'rating DESC',
    'terbaru' => 'created_at DESC',
    default => 'created_at DESC'
};

$stmt = $pdo->prepare("SELECT * FROM users WHERE $where ORDER BY $order");
$stmt->execute($params);
$mahasiswa = $stmt->fetchAll();

// Ambil daftar prodi unik untuk filter
$prodi_list = $pdo->query("SELECT DISTINCT prodi FROM users WHERE role='mahasiswa' AND prodi IS NOT NULL ORDER BY prodi")->fetchAll(PDO::FETCH_COLUMN);

$total = count($mahasiswa);
$avg_rating = $pdo->query("SELECT AVG(rating) FROM users WHERE role='mahasiswa'")->fetchColumn() ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Mahasiswa - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .page-header {
            background: linear-gradient(135deg, #0d6efd 0%, #6f42c1 100%);
            border-radius: 24px;
            padding: 2rem;
            color: white;
            margin-bottom: 1.5rem;
            position: relative;
            overflow: hidden;
        }
        .page-header::before {
            content: '';
            position: absolute;
            top: -50%; right: -10%;
            width: 300px; height: 300px;
            background: radial-gradient(circle, rgba(255,255,255,0.15), transparent 70%);
            border-radius: 50%;
        }
        .summary-card {
            background: white;
            border-radius: 16px;
            padding: 1.2rem;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(0,0,0,0.04);
            transition: all 0.3s;
        }
        .summary-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
        }
        .summary-icon {
            width: 48px; height: 48px;
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.3rem; color: white;
        }
        .student-card {
            background: white;
            border-radius: 16px;
            padding: 1.5rem;
            border: 1px solid rgba(0,0,0,0.04);
            box-shadow: var(--shadow-sm);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }
        .student-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: linear-gradient(90deg, #0d6efd, #6f42c1);
            transform: scaleX(0);
            transition: transform 0.4s;
        }
        .student-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-lg);
        }
        .student-card:hover::before {
            transform: scaleX(1);
        }
        .student-avatar {
            width: 70px; height: 70px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid white;
            box-shadow: 0 4px 15px rgba(13, 110, 253, 0.2);
            transition: transform 0.3s;
        }
        .student-card:hover .student-avatar {
            transform: scale(1.08);
        }
        .rating-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 10px;
            border-radius: 20px;
            background: rgba(255, 193, 7, 0.15);
            color: #d97706;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .filter-pill {
            padding: 6px 16px;
            border-radius: 20px;
            border: 2px solid #e9ecef;
            background: white;
            font-size: 0.85rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            color: #495057;
        }
        .filter-pill:hover {
            border-color: #0d6efd;
            color: #0d6efd;
        }
        .filter-pill.active {
            background: linear-gradient(135deg, #0d6efd, #6f42c1);
            color: white;
            border-color: transparent;
        }
        .view-toggle {
            display: inline-flex;
            background: white;
            border-radius: 10px;
            padding: 4px;
            border: 1px solid #e9ecef;
        }
        .view-toggle button {
            padding: 6px 12px;
            border: none;
            background: transparent;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .view-toggle button.active {
            background: linear-gradient(135deg, #0d6efd, #6f42c1);
            color: white;
        }
        .search-modern {
            position: relative;
        }
        .search-modern input {
            padding: 12px 16px 12px 44px;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            width: 100%;
            font-size: 0.9rem;
            transition: all 0.3s;
            background: white;
        }
        .search-modern input:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1);
            outline: none;
        }
        .search-modern i {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #adb5bd;
        }
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
        }
        .empty-state-icon {
            width: 120px; height: 120px;
            margin: 0 auto 1.5rem;
            background: linear-gradient(135deg, rgba(13,110,253,0.1), rgba(111,66,193,0.1));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            animation: bounce 2s infinite;
        }
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        .modal-modern .modal-content {
            border: none;
            border-radius: 24px;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0,0,0,0.2);
        }
        .modal-modern .modal-header {
            background: linear-gradient(135deg, #0d6efd, #6f42c1);
            color: white;
            border: none;
            padding: 1.5rem;
        }
        .modal-modern .modal-header .btn-close {
            filter: invert(1);
        }
        .profile-header {
            background: linear-gradient(135deg, #0d6efd, #6f42c1);
            padding: 2rem;
            color: white;
            text-align: center;
            position: relative;
        }
        .profile-header::after {
            content: '';
            position: absolute;
            bottom: -20px; left: 0; right: 0;
            height: 40px;
            background: white;
            border-radius: 50% 50% 0 0 / 100% 100% 0 0;
        }
        .profile-avatar-large {
            width: 100px; height: 100px;
            border-radius: 50%;
            border: 4px solid white;
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
            margin-bottom: 1rem;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 0.8rem 0;
            border-bottom: 1px dashed #e9ecef;
        }
        .info-row:last-child { border-bottom: none; }
        .info-label {
            color: #6c757d;
            font-size: 0.85rem;
            font-weight: 500;
        }
        .info-value {
            font-weight: 600;
            color: #1a1a2e;
            font-size: 0.9rem;
        }
        .action-btn {
            width: 36px; height: 36px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center; justify-content: center;
            border: none;
            transition: all 0.3s;
            cursor: pointer;
        }
        .action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }
        .btn-view { background: rgba(13, 110, 253, 0.1); color: #0d6efd; }
        .btn-view:hover { background: #0d6efd; color: white; }
        .btn-delete { background: rgba(220, 53, 69, 0.1); color: #dc3545; }
        .btn-delete:hover { background: #dc3545; color: white; }
        .fade-in-card {
            animation: fadeInCard 0.5s ease-out backwards;
        }
        @keyframes fadeInCard {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="bg-blobs">
        <div class="blob blob-1"></div>
        <div class="blob blob-2"></div>
        <div class="blob blob-3"></div>
    </div>

    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <div class="topbar-modern">
            <button class="topbar-icon-btn d-lg-none me-2" id="sidebarToggle">
                <i class="bi bi-list"></i>
            </button>
            <div class="topbar-search d-none d-md-block">
                <i class="bi bi-search"></i>
                <input type="text" placeholder="Cari data mahasiswa...">
            </div>
            <div class="topbar-actions">
                <div class="dropdown">
                    <div class="topbar-user" data-bs-toggle="dropdown">
                        <img src="../assets/img/<?= htmlspecialchars($_SESSION['foto'] ?? 'default.jpg') ?>" alt="Admin">
                        <div class="topbar-user-info d-none d-md-block">
                            <h6><?= htmlspecialchars($_SESSION['nama']) ?></h6>
                            <small>Administrator</small>
                        </div>
                        <i class="bi bi-chevron-down small text-muted"></i>
                    </div>
                    <div class="dropdown-menu dropdown-menu-end dropdown-menu-modern">
                        <a href="../logout.php" class="dropdown-item-modern text-danger">
                            <i class="bi bi-box-arrow-right"></i>
                            <div><div class="fw-semibold small">Logout</div></div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="content-wrapper">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" style="border-radius: 12px; border: none;">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= htmlspecialchars($_SESSION['success']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <!-- Page Header -->
            <div class="page-header fade-in-up">
                <div class="row align-items-center position-relative" style="z-index: 2;">
                    <div class="col-md-8">
                        <small class="opacity-75"><i class="bi bi-people-fill me-1"></i> Manajemen Pengguna</small>
                        <h2 class="fw-bold mt-1 mb-2">Data Mahasiswa</h2>
                        <p class="mb-0 opacity-90">Kelola semua akun mahasiswa yang terdaftar di sistem TITIPIN</p>
                    </div>
                    <div class="col-md-4 text-md-end mt-3 mt-md-0">
                        <div class="d-inline-flex gap-2">
                            <div class="bg-white bg-opacity-25 rounded-3 px-3 py-2">
                                <small class="d-block opacity-75">Total</small>
                                <h4 class="mb-0 fw-bold"><?= $total ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Summary Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-4 fade-in-up stagger-1">
                    <div class="summary-card">
                        <div class="d-flex align-items-center gap-3">
                            <div class="summary-icon" style="background: linear-gradient(135deg, #0d6efd, #6f42c1);">
                                <i class="bi bi-people-fill"></i>
                            </div>
                            <div>
                                <p class="text-muted small mb-0">Total Mahasiswa</p>
                                <h4 class="fw-bold mb-0"><?= $total ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 fade-in-up stagger-2">
                    <div class="summary-card">
                        <div class="d-flex align-items-center gap-3">
                            <div class="summary-icon" style="background: linear-gradient(135deg, #ffc107, #fd7e14);">
                                <i class="bi bi-star-fill"></i>
                            </div>
                            <div>
                                <p class="text-muted small mb-0">Rata-rata Rating</p>
                                <h4 class="fw-bold mb-0"><?= number_format($avg_rating, 2) ?> <small class="text-muted">/ 5</small></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 fade-in-up stagger-3">
                    <div class="summary-card">
                        <div class="d-flex align-items-center gap-3">
                            <div class="summary-icon" style="background: linear-gradient(135deg, #20c997, #0dcaf0);">
                                <i class="bi bi-mortarboard-fill"></i>
                            </div>
                            <div>
                                <p class="text-muted small mb-0">Program Studi</p>
                                <h4 class="fw-bold mb-0"><?= count($prodi_list) ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filter & Search -->
            <div class="modern-card mb-4 fade-in-up stagger-4">
                <div class="modern-card-body">
                    <form method="GET" class="row g-3 align-items-end">
                        <div class="col-md-5">
                            <label class="form-label small fw-semibold">
                                <i class="bi bi-search text-primary"></i> Pencarian
                            </label>
                            <div class="search-modern">
                                <i class="bi bi-search"></i>
                                <input type="text" name="search" placeholder="Cari nama, NPM, atau email..." 
                                       value="<?= htmlspecialchars($search) ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-semibold">
                                <i class="bi bi-mortarboard text-primary"></i> Program Studi
                            </label>
                            <select name="prodi" class="form-select" style="border-radius: 12px; padding: 11px 16px; border: 2px solid #e9ecef;">
                                <option value="">Semua Prodi</option>
                                <?php foreach ($prodi_list as $p): ?>
                                    <option value="<?= htmlspecialchars($p) ?>" <?= $prodi_filter == $p ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($p) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small fw-semibold">
                                <i class="bi bi-sort-down text-primary"></i> Urutkan
                            </label>
                            <select name="sort" class="form-select" style="border-radius: 12px; padding: 11px 16px; border: 2px solid #e9ecef;">
                                <option value="terbaru" <?= $sort=='terbaru'?'selected':'' ?>>Terbaru</option>
                                <option value="nama" <?= $sort=='nama'?'selected':'' ?>>Nama A-Z</option>
                                <option value="rating" <?= $sort=='rating'?'selected':'' ?>>Rating Tertinggi</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-gradient w-100">
                                <i class="bi bi-funnel-fill me-1"></i> Filter
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Students Grid -->
            <?php if (empty($mahasiswa)): ?>
                <div class="modern-card">
                    <div class="empty-state">
                        <div class="empty-state-icon">
                            <i class="bi bi-people" style="font-size: 3rem; color: #0d6efd;"></i>
                        </div>
                        <h5 class="fw-bold">Tidak ada data mahasiswa</h5>
                        <p class="text-muted">Coba ubah filter pencarian Anda</p>
                        <a href="mahasiswa.php" class="btn btn-gradient">
                            <i class="bi bi-arrow-clockwise me-1"></i> Reset Filter
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <div class="row g-3">
                    <?php foreach ($mahasiswa as $i => $m): ?>
                        <div class="col-xl-4 col-md-6" style="animation-delay: <?= $i * 0.05 ?>s;">
                            <div class="student-card fade-in-card">
                                <div class="d-flex align-items-start gap-3 mb-3">
                                    <img src="../assets/img/<?= htmlspecialchars($m['foto'] ?: 'default.jpg') ?>" 
                                         class="student-avatar" alt="Avatar">
                                    <div class="flex-grow-1 min-w-0">
                                        <h6 class="fw-bold mb-1 text-truncate"><?= htmlspecialchars($m['nama']) ?></h6>
                                        <small class="text-muted d-block">
                                            <i class="bi bi-card-text"></i> <?= htmlspecialchars($m['npm']) ?>
                                        </small>
                                        <?php if ($m['rating'] > 0): ?>
                                            <span class="rating-badge mt-1">
                                                <i class="bi bi-star-fill"></i>
                                                <?= number_format($m['rating'], 1) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-light text-muted mt-1">Belum ada rating</span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="d-flex align-items-center gap-2 mb-2">
                                        <i class="bi bi-envelope text-primary small"></i>
                                        <small class="text-truncate"><?= htmlspecialchars($m['email']) ?></small>
                                    </div>
                                    <div class="d-flex align-items-center gap-2 mb-2">
                                        <i class="bi bi-mortarboard text-primary small"></i>
                                        <small><?= htmlspecialchars($m['prodi'] ?: '-') ?> • <?= htmlspecialchars($m['kelas'] ?: '-') ?></small>
                                    </div>
                                    <div class="d-flex align-items-center gap-2">
                                        <i class="bi bi-calendar3 text-primary small"></i>
                                        <small>Bergabung <?= date('d M Y', strtotime($m['created_at'])) ?></small>
                                    </div>
                                </div>

                                <div class="d-flex gap-2 pt-2 border-top">
                                    <button class="action-btn btn-view flex-grow-1" 
                                            data-bs-toggle="modal" data-bs-target="#detail<?= $m['id'] ?>"
                                            title="Lihat Detail">
                                        <i class="bi bi-eye-fill"></i>
                                    </button>
                                    <a href="https://wa.me/<?= preg_replace('/^0/', '62', $m['no_hp']) ?>" 
                                       class="action-btn flex-grow-1" 
                                       style="background: rgba(37, 211, 102, 0.1); color: #25d366;"
                                       title="WhatsApp" target="_blank">
                                        <i class="bi bi-whatsapp"></i>
                                    </a>
                                    <a href="?hapus=<?= $m['id'] ?>" 
                                       class="action-btn btn-delete flex-grow-1"
                                       onclick="return confirm('Yakin ingin menghapus mahasiswa ini?')"
                                       title="Hapus">
                                        <i class="bi bi-trash-fill"></i>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Modal Detail -->
                        <div class="modal fade modal-modern" id="detail<?= $m['id'] ?>" tabindex="-1">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title fw-bold">
                                            <i class="bi bi-person-badge me-2"></i> Detail Mahasiswa
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="profile-header">
                                        <img src="../assets/img/<?= htmlspecialchars($m['foto'] ?: 'default.jpg') ?>" 
                                             class="profile-avatar-large" alt="Avatar">
                                        <h5 class="fw-bold mb-1"><?= htmlspecialchars($m['nama']) ?></h5>
                                        <small class="opacity-75"><?= htmlspecialchars($m['npm']) ?></small>
                                        <?php if ($m['rating'] > 0): ?>
                                            <div class="mt-2">
                                                <?php for ($s = 1; $s <= 5; $s++): ?>
                                                    <i class="bi bi-star<?= $s <= round($m['rating']) ? '-fill' : '' ?>"></i>
                                                <?php endfor; ?>
                                                <small class="ms-1">(<?= number_format($m['rating'], 1) ?>)</small>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="modal-body px-4 py-4">
                                        <div class="info-row">
                                            <span class="info-label"><i class="bi bi-envelope me-2"></i>Email</span>
                                            <span class="info-value"><?= htmlspecialchars($m['email']) ?></span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label"><i class="bi bi-phone me-2"></i>No. HP</span>
                                            <span class="info-value"><?= htmlspecialchars($m['no_hp'] ?: '-') ?></span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label"><i class="bi bi-mortarboard me-2"></i>Program Studi</span>
                                            <span class="info-value"><?= htmlspecialchars($m['prodi'] ?: '-') ?></span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label"><i class="bi bi-building me-2"></i>Kelas</span>
                                            <span class="info-value"><?= htmlspecialchars($m['kelas'] ?: '-') ?></span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label"><i class="bi bi-calendar3 me-2"></i>Tanggal Daftar</span>
                                            <span class="info-value"><?= date('d M Y, H:i', strtotime($m['created_at'])) ?></span>
                                        </div>
                                    </div>
                                    <div class="modal-footer border-0 px-4 pb-4">
                                        <button type="button" class="btn btn-light" data-bs-dismiss="modal" style="border-radius: 10px;">
                                            Tutup
                                        </button>
                                        <a href="https://wa.me/<?= preg_replace('/^0/', '62', $m['no_hp']) ?>" 
                                           class="btn btn-gradient" target="_blank">
                                            <i class="bi bi-whatsapp me-1"></i> Hubungi via WA
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('sidebarToggle')?.addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
        });
    </script>
</body>
</html>