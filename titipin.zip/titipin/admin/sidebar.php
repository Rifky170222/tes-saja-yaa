<aside class="sidebar bg-dark text-white p-3" style="width: 260px; min-height: 100vh;">
    <div class="text-center mb-4">
        <h5 class="fw-bold text-warning mb-1">
            <i class="bi bi-box-seam"></i> TITIPIN
        </h5>
        <small class="text-muted">Admin Panel</small>
    </div>
    
    <nav>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="mahasiswa.php">
                    <i class="bi bi-people"></i> Data Mahasiswa
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="kategori.php">
                    <i class="bi bi-tag"></i> Kategori Barang
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="titipan.php">
                    <i class="bi bi-box-seam"></i> Semua Titipan
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="laporan.php">
                    <i class="bi bi-file-earmark-text"></i> Laporan
                </a>
            </li>
            <li class="nav-item mt-3">
                <a class="nav-link text-white" href="../logout.php" onclick="return confirm('Yakin logout?')">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </li>
        </ul>
    </nav>
</aside>