<?php
require_once '../config/database.php';
cekLogin();
cekRole('admin');

$tgl_awal = $_GET['tgl_awal'] ?? date('Y-m-d', strtotime('-30 days'));
$tgl_akhir = $_GET['tgl_akhir'] ?? date('Y-m-d');
$status = $_GET['status'] ?? '';

$where = "DATE(t.tanggal_pengambilan) BETWEEN ? AND ?";
$params = [$tgl_awal, $tgl_akhir];

if ($status !== '') {
    $where .= " AND t.status = ?";
    $params[] = $status;
}

$stmt = $pdo->prepare("SELECT t.*, p.nama as pemilik_nama, b.nama as pembawa_nama, k.nama_kategori
                       FROM titipan t 
                       JOIN users p ON t.pemilik_id = p.id 
                       LEFT JOIN users b ON t.pembawa_id = b.id 
                       JOIN kategori k ON t.kategori_id = k.id 
                       WHERE $where 
                       ORDER BY t.tanggal_pengambilan DESC");
$stmt->execute($params);
$laporan = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cetak Laporan</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; }
        .header h2 { margin: 0; color: #0d6efd; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #333; padding: 6px; text-align: left; font-size: 10px; }
        th { background: #0d6efd; color: white; }
        .footer { margin-top: 20px; text-align: right; }
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="text-align:center; margin-bottom:20px;">
        <button onclick="window.print()">🖨️ Cetak</button>
    </div>
    
    <div class="header">
        <h2>TITIPIN - Sistem Titip Barang Antar Mahasiswa</h2>
        <p>Laporan Transaksi Periode <?= formatTanggal($tgl_awal) ?> s/d <?= formatTanggal($tgl_akhir) ?></p>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Pemilik</th>
                <th>Pembawa</th>
                <th>Barang</th>
                <th>Tanggal</th>
                <th>Status</th>
                <th>Biaya</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; $total = 0; foreach ($laporan as $l): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= e($l['kode_titipan']) ?></td>
                    <td><?= e($l['pemilik_nama']) ?></td>
                    <td><?= e($l['pembawa_nama'] ?? '-') ?></td>
                    <td><?= e($l['nama_barang']) ?></td>
                    <td><?= formatTanggal($l['tanggal_pengambilan']) ?></td>
                    <td><?= e($l['status']) ?></td>
                    <td><?= formatRupiah($l['biaya_jasa']) ?></td>
                </tr>
                <?php $total += $l['biaya_jasa']; ?>
            <?php endforeach; ?>
            <tr>
                <td colspan="7" style="text-align:right"><strong>Total Biaya Jasa:</strong></td>
                <td><strong><?= formatRupiah($total) ?></strong></td>
            </tr>
        </tbody>
    </table>
    
    <div class="footer">
        <p>Dicetak pada: <?= date('d M Y H:i') ?></p>
    </div>
    
    <script>
        window.onload = function() { window.print(); }
    </script>
</body>
</html>