<?php
require_once '../config/database.php';
cekLogin();
cekRole('admin');

$tgl_awal = $_GET['tgl_awal'] ?? date('Y-m-d', strtotime('-30 days'));
$tgl_akhir = $_GET['tgl_akhir'] ?? date('Y-m-d');
$status = $_GET['status'] ?? '';

$where = "DATE(t.tanggal_pengambilan) BETWEEN ? AND ?";
$params = [$tgl_awal, $tgl_akhir];

if ($status !== '') {
    $where .= " AND t.status = ?";
    $params[] = $status;
}

$stmt = $pdo->prepare("SELECT t.*, 
                       p.nama as pemilik_nama,
                       b.nama as pembawa_nama,
                       k.nama_kategori
                       FROM titipan t 
                       JOIN users p ON t.pemilik_id = p.id 
                       LEFT JOIN users b ON t.pembawa_id = b.id 
                       JOIN kategori k ON t.kategori_id = k.id 
                       WHERE $where 
                       ORDER BY t.tanggal_pengambilan DESC");
$stmt->execute($params);
$laporan = $stmt->fetchAll();

// Summary
$total_transaksi = count($laporan);
$total_biaya = array_sum(array_column($laporan, 'biaya_jasa'));
$total_selesai = count(array_filter($laporan, fn($l) => $l['status'] === 'Selesai'));
$avg_biaya = $total_transaksi > 0 ? $total_biaya / $total_transaksi : 0;

$status_config = [
    'Menunggu' => ['color' => '#ffc107', 'icon' => 'hourglass-split'],
    'Diterima' => ['color' => '#0dcaf0', 'icon' => 'check-circle'],
    'Barang Diambil' => ['color' => '#fd7e14', 'icon' => 'box'],
    'Dalam Perjalanan' => ['color' => '#6f42c1', 'icon' => 'truck'],
    'Selesai' => ['color' => '#20c997', 'icon' => 'check-circle-fill'],
    'Dibatalkan' => ['color' => '#dc3545', 'icon' => 'x-circle-fill'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .page-header {
            background: linear-gradient(135deg, #fd7e14 0%, #ffc107 100%);
            border-radius: 24px;
            padding: 2rem;
            color: white;
            margin-bottom: 1.5rem;
            position: relative;
            overflow: hidden;
        }
        .page-header::before {
            content: '';
            position: absolute;
            top: -50%; right: -10%;
            width: 300px; height: 300px;
            background: radial-gradient(circle, rgba(255,255,255,0.15), transparent 70%);
            border-radius: 50%;
        }
        .summary-card {
            background: white;
            border-radius: 20px;
            padding: 1.5rem;
            border: 1px solid rgba(0,0,0,0.04);
            box-shadow: var(--shadow-sm);
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        .summary-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: var(--card-gradient);
        }
        .summary-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
        }
        .summary-icon {
            width: 56px; height: 56px;
            border-radius: 16px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.5rem; color: white;
            background: var(--card-gradient);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }
        .summary-value {
            font-size: 1.8rem;
            font-weight: 800;
            color: #1a1a2e;
            margin: 0.5rem 0 0.2rem;
        }
        .summary-label {
            color: #6c757d;
            font-size: 0.85rem;
            font-weight: 500;
        }
        .filter-card {
            background: white;
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(0,0,0,0.04);
        }
        .input-modern {
            padding: 11px 16px;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            width: 100%;
            font-size: 0.9rem;
            transition: all 0.3s;
            background: white;
        }
        .input-modern:focus {
            border-color: #fd7e14;
            box-shadow: 0 0 0 4px rgba(253, 126, 20, 0.1);
            outline: none;
        }
        .btn-gradient-orange {
            background: linear-gradient(135deg, #fd7e14, #ffc107);
            border: none;
            color: white;
            padding: 11px 24px;
            border-radius: 12px;
            font-weight: 600;
            box-shadow: 0 5px 15px rgba(253, 126, 20, 0.3);
            transition: all 0.3s;
        }
        .btn-gradient-orange:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(253, 126, 20, 0.4);
            color: white;
        }
        .btn-gradient-green {
            background: linear-gradient(135deg, #20c997, #0dcaf0);
            border: none;
            color: white;
            padding: 11px 24px;
            border-radius: 12px;
            font-weight: 600;
            box-shadow: 0 5px 15px rgba(32, 201, 151, 0.3);
            transition: all 0.3s;
        }
        .btn-gradient-green:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(32, 201, 151, 0.4);
            color: white;
        }
        .modern-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }
        .modern-table thead th {
            background: linear-gradient(135deg, #f8f9fc, #eef2ff);
            color: #495057;
            font-weight: 600;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 14px 16px;
            border: none;
        }
        .modern-table thead th:first-child { border-radius: 12px 0 0 12px; }
        .modern-table thead th:last-child { border-radius: 0 12px 12px 0; }
        .modern-table tbody tr {
            transition: all 0.3s;
        }
        .modern-table tbody tr:hover {
            background: rgba(13, 110, 253, 0.03);
            transform: scale(1.005);
        }
        .modern-table tbody td {
            padding: 14px 16px;
            border-bottom: 1px solid #f1f3f5;
            font-size: 0.88rem;
            vertical-align: middle;
        }
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .kode-badge {
            background: linear-gradient(135deg, rgba(13,110,253,0.1), rgba(111,66,193,0.1));
            color: #0d6efd;
            padding: 4px 10px;
            border-radius: 8px;
            font-size: 0.78rem;
            font-weight: 600;
            font-family: 'Courier New', monospace;
        }
        .user-chip {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 0.85rem;
        }
        .biaya-highlight {
            font-weight: 700;
            color: #20c997;
        }
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
        }
        .empty-state-icon {
            width: 120px; height: 120px;
            margin: 0 auto 1.5rem;
            background: linear-gradient(135deg, rgba(253,126,20,0.1), rgba(255,193,7,0.1));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            animation: bounce 2s infinite;
        }
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        .fade-in-up {
            animation: fadeInUp 0.6s ease-out backwards;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="bg-blobs">
        <div class="blob blob-1"></div>
        <div class="blob blob-2"></div>
        <div class="blob blob-3"></div>
    </div>

    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <div class="topbar-modern">
            <button class="topbar-icon-btn d-lg-none me-2" id="sidebarToggle">
                <i class="bi bi-list"></i>
            </button>
            <div class="topbar-search d-none d-md-block">
                <i class="bi bi-search"></i>
                <input type="text" placeholder="Cari data...">
            </div>
            <div class="topbar-actions">
                <div class="dropdown">
                    <div class="topbar-user" data-bs-toggle="dropdown">
                        <img src="../assets/img/<?= htmlspecialchars($_SESSION['foto'] ?? 'default.jpg') ?>" alt="Admin">
                        <div class="topbar-user-info d-none d-md-block">
                            <h6><?= htmlspecialchars($_SESSION['nama']) ?></h6>
                            <small>Administrator</small>
                        </div>
                        <i class="bi bi-chevron-down small text-muted"></i>
                    </div>
                    <div class="dropdown-menu dropdown-menu-end dropdown-menu-modern">
                        <a href="../logout.php" class="dropdown-item-modern text-danger">
                            <i class="bi bi-box-arrow-right"></i>
                            <div><div class="fw-semibold small">Logout</div></div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="content-wrapper">
            <!-- Page Header -->
            <div class="page-header fade-in-up">
                <div class="row align-items-center position-relative" style="z-index: 2;">
                    <div class="col-md-8">
                        <small class="opacity-75"><i class="bi bi-file-earmark-text-fill me-1"></i> Analitik & Laporan</small>
                        <h2 class="fw-bold mt-1 mb-2">Laporan Transaksi</h2>
                        <p class="mb-0 opacity-90">Analisis data transaksi titipan dalam periode tertentu</p>
                    </div>
                    <div class="col-md-4 text-md-end mt-3 mt-md-0">
                        <a href="cetak_laporan.php?<?= http_build_query($_GET) ?>" target="_blank" 
                           class="btn btn-light fw-semibold">
                            <i class="bi bi-printer me-1"></i> Cetak Laporan
                        </a>
                    </div>
                </div>
            </div>

            <!-- Summary Cards -->
            <div class="row g-3 mb-4">
                <div class="col-xl-3 col-md-6 fade-in-up stagger-1">
                    <div class="summary-card" style="--card-gradient: linear-gradient(135deg, #0d6efd, #6f42c1);">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="summary-label">Total Transaksi</p>
                                <h3 class="summary-value"><?= $total_transaksi ?></h3>
                                <small class="text-muted">Periode ini</small>
                            </div>
                            <div class="summary-icon"><i class="bi bi-receipt"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 fade-in-up stagger-2">
                    <div class="summary-card" style="--card-gradient: linear-gradient(135deg, #20c997, #0dcaf0);">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="summary-label">Total Biaya Jasa</p>
                                <h3 class="summary-value">Rp <?= number_format($total_biaya, 0, ',', '.') ?></h3>
                                <small class="text-muted">Akumulasi</small>
                            </div>
                            <div class="summary-icon"><i class="bi bi-cash-stack"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 fade-in-up stagger-3">
                    <div class="summary-card" style="--card-gradient: linear-gradient(135deg, #fd7e14, #ffc107);">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="summary-label">Transaksi Selesai</p>
                                <h3 class="summary-value"><?= $total_selesai ?></h3>
                                <small class="text-muted">Berhasil diantar</small>
                            </div>
                            <div class="summary-icon"><i class="bi bi-check-circle-fill"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 fade-in-up stagger-4">
                    <div class="summary-card" style="--card-gradient: linear-gradient(135deg, #6f42c1, #d63384);">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="summary-label">Rata-rata Biaya</p>
                                <h3 class="summary-value">Rp <?= number_format($avg_biaya, 0, ',', '.') ?></h3>
                                <small class="text-muted">Per transaksi</small>
                            </div>
                            <div class="summary-icon"><i class="bi bi-graph-up"></i></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filter -->
            <div class="filter-card mb-4 fade-in-up stagger-4">
                <form method="GET" class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label small fw-semibold">
                            <i class="bi bi-calendar-date text-primary"></i> Tanggal Awal
                        </label>
                        <input type="date" name="tgl_awal" class="input-modern" value="<?= htmlspecialchars($tgl_awal) ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-semibold">
                            <i class="bi bi-calendar-date text-primary"></i> Tanggal Akhir
                        </label>
                        <input type="date" name="tgl_akhir" class="input-modern" value="<?= htmlspecialchars($tgl_akhir) ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-semibold">
                            <i class="bi bi-funnel text-primary"></i> Status
                        </label>
                        <select name="status" class="input-modern">
                            <option value="">Semua Status</option>
                            <option value="Menunggu" <?= $status=='Menunggu'?'selected':'' ?>>Menunggu</option>
                            <option value="Diterima" <?= $status=='Diterima'?'selected':'' ?>>Diterima</option>
                            <option value="Barang Diambil" <?= $status=='Barang Diambil'?'selected':'' ?>>Barang Diambil</option>
                            <option value="Dalam Perjalanan" <?= $status=='Dalam Perjalanan'?'selected':'' ?>>Dalam Perjalanan</option>
                            <option value="Selesai" <?= $status=='Selesai'?'selected':'' ?>>Selesai</option>
                            <option value="Dibatalkan" <?= $status=='Dibatalkan'?'selected':'' ?>>Dibatalkan</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-gradient-orange w-100">
                            <i class="bi bi-search me-1"></i> Tampilkan Laporan
                        </button>
                    </div>
                </form>
            </div>

            <!-- Chart & Table -->
            <div class="row g-3 mb-4">
                <div class="col-lg-5 fade-in-up stagger-5">
                    <div class="modern-card h-100">
                        <div class="modern-card-header">
                            <h6><i class="bi bi-pie-chart-fill"></i> Distribusi Status</h6>
                        </div>
                        <div class="modern-card-body">
                            <canvas id="chartPie" height="220"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7 fade-in-up stagger-5">
                    <div class="modern-card h-100">
                        <div class="modern-card-header">
                            <h6><i class="bi bi-bar-chart-fill"></i> Tren Transaksi</h6>
                        </div>
                        <div class="modern-card-body">
                            <canvas id="chartLine" height="220"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Table -->
            <div class="modern-card fade-in-up stagger-5">
                <div class="modern-card-header">
                    <h6><i class="bi bi-table"></i> Detail Transaksi</h6>
                    <span class="badge bg-primary bg-opacity-10 text-primary">
                        <?= $total_transaksi ?> data
                    </span>
                </div>
                <div class="modern-card-body p-0">
                    <?php if (empty($laporan)): ?>
                        <div class="empty-state">
                            <div class="empty-state-icon">
                                <i class="bi bi-file-earmark" style="font-size: 3rem; color: #fd7e14;"></i>
                            </div>
                            <h5 class="fw-bold">Tidak ada data</h5>
                            <p class="text-muted">Tidak ada transaksi pada periode yang dipilih</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="modern-table">
                                <thead>
                                    <tr>
                                        <th>Kode</th>
                                        <th>Barang</th>
                                        <th>Pemilik</th>
                                        <th>Pembawa</th>
                                        <th>Tanggal</th>
                                        <th>Status</th>
                                        <th class="text-end">Biaya</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($laporan as $l): 
                                        $config = $status_config[$l['status']] ?? ['color' => '#0d6efd', 'icon' => 'box'];
                                    ?>
                                        <tr>
                                            <td><span class="kode-badge"><?= htmlspecialchars($l['kode_titipan']) ?></span></td>
                                            <td>
                                                <div class="fw-semibold"><?= htmlspecialchars($l['nama_barang']) ?></div>
                                                <small class="text-muted"><?= htmlspecialchars($l['nama_kategori']) ?></small>
                                            </td>
                                            <td>
                                                <span class="user-chip">
                                                    <i class="bi bi-person-fill text-primary"></i>
                                                    <?= htmlspecialchars($l['pemilik_nama']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($l['pembawa_nama']): ?>
                                                    <span class="user-chip">
                                                        <i class="bi bi-truck text-success"></i>
                                                        <?= htmlspecialchars($l['pembawa_nama']) ?>
                                                    </span>
                                                <?php else: ?>
                                                    <small class="text-muted fst-italic">-</small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <small><?= date('d M Y', strtotime($l['tanggal_pengambilan'])) ?></small>
                                            </td>
                                            <td>
                                                <span class="status-badge" style="background: <?= $config['color'] ?>20; color: <?= $config['color'] ?>;">
                                                    <i class="bi bi-<?= $config['icon'] ?>"></i>
                                                    <?= htmlspecialchars($l['status']) ?>
                                                </span>
                                            </td>
                                            <td class="text-end">
                                                <span class="biaya-highlight">Rp <?= number_format($l['biaya_jasa'], 0, ',', '.') ?></span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <tr style="background: linear-gradient(135deg, rgba(32,201,151,0.05), rgba(13,202,240,0.05));">
                                        <td colspan="6" class="text-end fw-bold">TOTAL</td>
                                        <td class="text-end">
                                            <span class="biaya-highlight" style="font-size: 1.1rem;">
                                                Rp <?= number_format($total_biaya, 0, ',', '.') ?>
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('sidebarToggle')?.addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
        });

        // Pie Chart
        const statusData = <?= json_encode(array_count_values(array_column($laporan, 'status'))) ?>;
        const statusColors = {
            'Menunggu': '#ffc107',
            'Diterima': '#0dcaf0',
            'Barang Diambil': '#fd7e14',
            'Dalam Perjalanan': '#6f42c1',
            'Selesai': '#20c997',
            'Dibatalkan': '#dc3545'
        };
        
        new Chart(document.getElementById('chartPie'), {
            type: 'doughnut',
            data: {
                labels: Object.keys(statusData),
                datasets: [{
                    data: Object.values(statusData),
                    backgroundColor: Object.keys(statusData).map(k => statusColors[k] || '#0d6efd'),
                    borderWidth: 3,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { padding: 15, font: { size: 11 } } }
                },
                cutout: '65%'
            }
        });

        // Line Chart
        const grouped = {};
        <?= json_encode($laporan) ?>.forEach(l => {
            const date = l.tanggal_pengambilan;
            grouped[date] = (grouped[date] || 0) + 1;
        });
        
        new Chart(document.getElementById('chartLine'), {
            type: 'line',
            data: {
                labels: Object.keys(grouped).sort(),
                datasets: [{
                    label: 'Jumlah Transaksi',
                    data: Object.values(grouped),
                    borderColor: '#fd7e14',
                    backgroundColor: 'rgba(253, 126, 20, 0.1)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 3,
                    pointBackgroundColor: '#fd7e14',
                    pointRadius: 5,
                    pointHoverRadius: 7
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } },
                    x: { grid: { display: false } }
                }
            }
        });
    </script>
</body>
</html>