<?php
require_once '../config/database.php';
cekLogin();
cekRole('admin');

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT t.*, k.nama_kategori, 
                       p.nama as pemilik_nama, p.no_hp as pemilik_hp, p.email as pemilik_email, p.npm as pemilik_npm,
                       b.nama as pembawa_nama, b.no_hp as pembawa_hp, b.npm as pembawa_npm
                       FROM titipan t 
                       JOIN kategori k ON t.kategori_id = k.id 
                       JOIN users p ON t.pemilik_id = p.id 
                       LEFT JOIN users b ON t.pembawa_id = b.id 
                       WHERE t.id = ?");
$stmt->execute([$id]);
$t = $stmt->fetch();

if (!$t) {
    $_SESSION['error'] = 'Titipan tidak ditemukan.';
    header('Location: titipan.php');
    exit;
}

// Aktivitas
$stmt = $pdo->prepare("SELECT a.*, u.nama FROM aktivitas a 
                       JOIN users u ON a.user_id = u.id 
                       WHERE a.titipan_id = ? ORDER BY a.created_at DESC");
$stmt->execute([$id]);
$aktivitas = $stmt->fetchAll();

// Rating
$stmt = $pdo->prepare("SELECT r.*, u.nama FROM rating r 
                       JOIN users u ON r.pemberi_id = u.id 
                       WHERE r.titipan_id = ?");
$stmt->execute([$id]);
$rating = $stmt->fetch();

$status_config = [
    'Menunggu' => ['color' => '#ffc107', 'icon' => 'hourglass-split', 'progress' => 15],
    'Diterima' => ['color' => '#0dcaf0', 'icon' => 'check-circle', 'progress' => 35],
    'Barang Diambil' => ['color' => '#fd7e14', 'icon' => 'box', 'progress' => 55],
    'Dalam Perjalanan' => ['color' => '#6f42c1', 'icon' => 'truck', 'progress' => 75],
    'Selesai' => ['color' => '#20c997', 'icon' => 'check-circle-fill', 'progress' => 100],
    'Dibatalkan' => ['color' => '#dc3545', 'icon' => 'x-circle-fill', 'progress' => 0],
];
$config = $status_config[$t['status']];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Titipan - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .page-header {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 24px;
            padding: 2rem;
            color: white;
            margin-bottom: 1.5rem;
            position: relative;
            overflow: hidden;
        }
        .page-header::before {
            content: '';
            position: absolute;
            top: -50%; right: -10%;
            width: 300px; height: 300px;
            background: radial-gradient(circle, rgba(255,255,255,0.1), transparent 70%);
            border-radius: 50%;
        }
        .kode-display {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(255,255,255,0.15);
            backdrop-filter: blur(10px);
            padding: 8px 16px;
            border-radius: 12px;
            font-family: 'Courier New', monospace;
            font-weight: 700;
            font-size: 1rem;
        }
        .status-display {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 30px;
            font-weight: 600;
            background: var(--status-color);
            color: white;
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        }
        .info-card {
            background: white;
            border-radius: 20px;
            padding: 1.8rem;
            border: 1px solid rgba(0,0,0,0.04);
            box-shadow: var(--shadow-sm);
            margin-bottom: 1.5rem;
        }
        .info-card-title {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px dashed #e9ecef;
        }
        .info-card-icon {
            width: 44px; height: 44px;
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            color: white;
            font-size: 1.2rem;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 0.8rem 0;
            border-bottom: 1px solid #f1f3f5;
            align-items: center;
        }
        .info-row:last-child { border-bottom: none; }
        .info-label {
            color: #6c757d;
            font-size: 0.85rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .info-value {
            font-weight: 600;
            color: #1a1a2e;
            font-size: 0.9rem;
            text-align: right;
        }
        .user-profile-card {
            background: linear-gradient(135deg, var(--user-color-1), var(--user-color-2));
            border-radius: 16px;
            padding: 1.5rem;
            color: white;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        .user-profile-card::before {
            content: '';
            position: absolute;
            top: -50%; right: -30%;
            width: 200px; height: 200px;
            background: radial-gradient(circle, rgba(255,255,255,0.15), transparent 70%);
            border-radius: 50%;
        }
        .user-avatar {
            width: 80px; height: 80px;
            border-radius: 50%;
            border: 4px solid white;
            object-fit: cover;
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
            margin-bottom: 1rem;
            position: relative;
            z-index: 2;
        }
        .progress-tracker {
            display: flex;
            justify-content: space-between;
            position: relative;
            margin: 2rem 0;
        }
        .progress-tracker::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 0; right: 0;
            height: 3px;
            background: #e9ecef;
            z-index: 0;
        }
        .progress-tracker::after {
            content: '';
            position: absolute;
            top: 20px;
            left: 0;
            width: var(--progress, 0%);
            height: 3px;
            background: linear-gradient(90deg, #0d6efd, #6f42c1);
            z-index: 1;
            transition: width 1s ease;
        }
        .progress-step {
            position: relative;
            z-index: 2;
            text-align: center;
            flex: 1;
        }
        .progress-dot {
            width: 40px; height: 40px;
            border-radius: 50%;
            background: white;
            border: 3px solid #e9ecef;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 0.5rem;
            font-size: 1rem;
            color: #adb5bd;
            transition: all 0.5s;
        }
        .progress-step.active .progress-dot {
            background: linear-gradient(135deg, #0d6efd, #6f42c1);
            border-color: transparent;
            color: white;
            box-shadow: 0 5px 15px rgba(13, 110, 253, 0.4);
            transform: scale(1.1);
        }
        .progress-step.completed .progress-dot {
            background: #20c997;
            border-color: transparent;
            color: white;
        }
        .progress-label {
            font-size: 0.7rem;
            font-weight: 600;
            color: #6c757d;
        }
        .progress-step.active .progress-label,
        .progress-step.completed .progress-label {
            color: #1a1a2e;
        }
        .timeline-item {
            display: flex;
            gap: 1rem;
            padding-bottom: 1.2rem;
            position: relative;
            animation: slideIn 0.5s ease-out backwards;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-10px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .timeline-item:not(:last-child)::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 35px;
            bottom: 0;
            width: 2px;
            background: linear-gradient(180deg, #0d6efd, transparent);
        }
        .timeline-dot {
            width: 32px; height: 32px;
            border-radius: 50%;
            background: linear-gradient(135deg, #0d6efd, #6f42c1);
            color: white;
            display: flex; align-items: center; justify-content: center;
            font-size: 0.85rem;
            flex-shrink: 0;
            box-shadow: 0 4px 10px rgba(13, 110, 253, 0.3);
        }
        .timeline-content {
            flex-grow: 1;
            background: #f8f9fc;
            padding: 0.8rem 1rem;
            border-radius: 12px;
        }
        .rating-card {
            background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);
            border-radius: 20px;
            padding: 1.5rem;
            color: white;
            position: relative;
            overflow: hidden;
        }
        .rating-card::before {
            content: '';
            position: absolute;
            top: -50%; right: -30%;
            width: 200px; height: 200px;
            background: radial-gradient(circle, rgba(255,255,255,0.2), transparent 70%);
            border-radius: 50%;
        }
        .rating-stars {
            font-size: 1.5rem;
            letter-spacing: 4px;
        }
        .fade-in-up {
            animation: fadeInUp 0.6s ease-out backwards;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="bg-blobs">
        <div class="blob blob-1"></div>
        <div class="blob blob-2"></div>
        <div class="blob blob-3"></div>
    </div>

    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <div class="topbar-modern">
            <button class="topbar-icon-btn d-lg-none me-2" id="sidebarToggle">
                <i class="bi bi-list"></i>
            </button>
            <div class="topbar-search d-none d-md-block">
                <i class="bi bi-search"></i>
                <input type="text" placeholder="Cari data...">
            </div>
            <div class="topbar-actions">
                <div class="dropdown">
                    <div class="topbar-user" data-bs-toggle="dropdown">
                        <img src="../assets/img/<?= htmlspecialchars($_SESSION['foto'] ?? 'default.jpg') ?>" alt="Admin">
                        <div class="topbar-user-info d-none d-md-block">
                            <h6><?= htmlspecialchars($_SESSION['nama']) ?></h6>
                            <small>Administrator</small>
                        </div>
                        <i class="bi bi-chevron-down small text-muted"></i>
                    </div>
                    <div class="dropdown-menu dropdown-menu-end dropdown-menu-modern">
                        <a href="../logout.php" class="dropdown-item-modern text-danger">
                            <i class="bi bi-box-arrow-right"></i>
                            <div><div class="fw-semibold small">Logout</div></div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="content-wrapper">
            <!-- Page Header -->
            <div class="page-header fade-in-up">
                <div class="position-relative" style="z-index: 2;">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
                        <div>
                            <small class="opacity-75">
                                <a href="titipan.php" class="text-white text-decoration-none">
                                    <i class="bi bi-arrow-left me-1"></i> Kembali
                                </a>
                            </small>
                            <h2 class="fw-bold mt-1 mb-2">Detail Titipan</h2>
                            <div class="d-flex gap-2 flex-wrap align-items-center">
                                <span class="kode-display">
                                    <i class="bi bi-hash"></i> <?= htmlspecialchars($t['kode_titipan']) ?>
                                </span>
                                <span class="status-display" style="--status-color: <?= $config['color'] ?>;">
                                    <i class="bi bi-<?= $config['icon'] ?>"></i>
                                    <?= htmlspecialchars($t['status']) ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Progress Tracker -->
            <?php if ($t['status'] !== 'Dibatalkan'): ?>
                <?php 
                $steps = ['Menunggu', 'Diterima', 'Barang Diambil', 'Dalam Perjalanan', 'Selesai'];
                $current_index = array_search($t['status'], $steps);
                $progress = ($current_index !== false) ? ($current_index / (count($steps) - 1)) * 100 : 0;
                ?>
                <div class="info-card fade-in-up stagger-1">
                    <div class="info-card-title">
                        <div class="info-card-icon" style="background: linear-gradient(135deg, #0d6efd, #6f42c1);">
                            <i class="bi bi-graph-up-arrow"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0">Progress Pengantaran</h6>
                            <small class="text-muted">Pantau perjalanan barang dari awal sampai selesai</small>
                        </div>
                    </div>
                    <div class="progress-tracker" style="--progress: <?= $progress ?>%;">
                        <?php foreach ($steps as $i => $step): 
                            $step_class = '';
                            if ($i < $current_index) $step_class = 'completed';
                            elseif ($i == $current_index) $step_class = 'active';
                        ?>
                            <div class="progress-step <?= $step_class ?>">
                                <div class="progress-dot">
                                    <?php if ($i < $current_index): ?>
                                        <i class="bi bi-check-lg"></i>
                                    <?php else: ?>
                                        <?= $i + 1 ?>
                                    <?php endif; ?>
                                </div>
                                <div class="progress-label"><?= $step ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="row g-3">
                <!-- Main Info -->
                <div class="col-lg-8">
                    <!-- Barang Info -->
                    <div class="info-card fade-in-up stagger-2">
                        <div class="info-card-title">
                            <div class="info-card-icon" style="background: linear-gradient(135deg, #6f42c1, #d63384);">
                                <i class="bi bi-box-seam-fill"></i>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-0">Informasi Barang</h6>
                                <small class="text-muted">Detail barang yang dititipkan</small>
                            </div>
                        </div>
                        <div class="info-row">
                            <span class="info-label"><i class="bi bi-tag text-primary"></i> Nama Barang</span>
                            <span class="info-value"><?= htmlspecialchars($t['nama_barang']) ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label"><i class="bi bi-collection text-primary"></i> Kategori</span>
                            <span class="info-value"><?= htmlspecialchars($t['nama_kategori']) ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label"><i class="bi bi-list-ol text-primary"></i> Jumlah</span>
                            <span class="info-value"><?= $t['jumlah'] ?> pcs</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label"><i class="bi bi-card-text text-primary"></i> Deskripsi</span>
                            <span class="info-value"><?= htmlspecialchars($t['deskripsi'] ?: '-') ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label"><i class="bi bi-sticky text-primary"></i> Catatan</span>
                            <span class="info-value"><?= htmlspecialchars($t['catatan'] ?: '-') ?></span>
                        </div>
                    </div>

                    <!-- Lokasi Info -->
                    <div class="info-card fade-in-up stagger-3">
                        <div class="info-card-title">
                            <div class="info-card-icon" style="background: linear-gradient(135deg, #20c997, #0dcaf0);">
                                <i class="bi bi-geo-alt-fill"></i>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-0">Rute Pengantaran</h6>
                                <small class="text-muted">Lokasi pengambilan dan tujuan</small>
                            </div>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-5">
                                <div class="p-3 rounded-3" style="background: rgba(13, 110, 253, 0.05); border-left: 4px solid #0d6efd;">
                                    <small class="text-muted d-block mb-1">
                                        <i class="bi bi-box-arrow-right"></i> Lokasi Pengambilan
                                    </small>
                                    <strong><?= htmlspecialchars($t['lokasi_pengambilan']) ?></strong>
                                </div>
                            </div>
                            <div class="col-md-2 d-flex align-items-center justify-content-center">
                                <i class="bi bi-arrow-right-circle-fill text-primary" style="font-size: 2rem;"></i>
                            </div>
                            <div class="col-md-5">
                                <div class="p-3 rounded-3" style="background: rgba(32, 201, 151, 0.05); border-left: 4px solid #20c997;">
                                    <small class="text-muted d-block mb-1">
                                        <i class="bi bi-geo-alt-fill"></i> Lokasi Tujuan
                                    </small>
                                    <strong><?= htmlspecialchars($t['lokasi_tujuan']) ?></strong>
                                </div>
                            </div>
                        </div>
                        <hr class="my-3">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="info-row">
                                    <span class="info-label"><i class="bi bi-calendar-event text-primary"></i> Tgl Pengambilan</span>
                                    <span class="info-value"><?= date('d M Y', strtotime($t['tanggal_pengambilan'])) ?></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-row">
                                    <span class="info-label"><i class="bi bi-calendar-check text-primary"></i> Batas Antar</span>
                                    <span class="info-value"><?= date('d M Y', strtotime($t['batas_pengantaran'])) ?></span>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="info-row">
                                    <span class="info-label"><i class="bi bi-cash-coin text-primary"></i> Biaya Jasa</span>
                                    <span class="info-value" style="color: #20c997; font-size: 1.1rem;">
                                        Rp <?= number_format($t['biaya_jasa'], 0, ',', '.') ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Aktivitas Timeline -->
                    <div class="info-card fade-in-up stagger-4">
                        <div class="info-card-title">
                            <div class="info-card-icon" style="background: linear-gradient(135deg, #fd7e14, #ffc107);">
                                <i class="bi bi-clock-history"></i>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-0">Log Aktivitas</h6>
                                <small class="text-muted">Riwayat perubahan status dan aktivitas</small>
                            </div>
                        </div>
                        <?php if (empty($aktivitas)): ?>
                            <p class="text-muted text-center py-3">Belum ada aktivitas tercatat</p>
                        <?php else: ?>
                            <?php foreach ($aktivitas as $i => $a): ?>
                                <div class="timeline-item" style="animation-delay: <?= $i * 0.1 ?>s;">
                                    <div class="timeline-dot">
                                        <i class="bi bi-circle-fill"></i>
                                    </div>
                                    <div class="timeline-content">
                                        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                                            <div>
                                                <strong><?= htmlspecialchars($a['nama']) ?></strong>
                                                <p class="mb-0 small mt-1"><?= htmlspecialchars($a['aktivitas']) ?></p>
                                            </div>
                                            <small class="text-muted">
                                                <i class="bi bi-clock"></i>
                                                <?= date('d M Y, H:i', strtotime($a['created_at'])) ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Sidebar Info -->
                <div class="col-lg-4">
                    <!-- Pemilik -->
                    <div class="user-profile-card fade-in-up stagger-2" style="--user-color-1: #0d6efd; --user-color-2: #6f42c1;">
                        <small class="opacity-75 d-block position-relative" style="z-index: 2;">
                            <i class="bi bi-person-badge"></i> Pemilik Barang
                        </small>
                        <img src="../assets/img/<?= htmlspecialchars($t['foto'] ?? 'default.jpg') ?>" 
                             class="user-avatar" alt="Avatar"
                             onerror="this.src='../assets/img/default.jpg'">
                        <h5 class="fw-bold position-relative" style="z-index: 2;"><?= htmlspecialchars($t['pemilik_nama']) ?></h5>
                        <small class="opacity-90 position-relative" style="z-index: 2;">NPM: <?= htmlspecialchars($t['pemilik_npm']) ?></small>
                        <hr class="border-light my-3 position-relative" style="z-index: 2;">
                        <div class="text-start position-relative" style="z-index: 2;">
                            <small class="d-block mb-2"><i class="bi bi-envelope me-2"></i><?= htmlspecialchars($t['pemilik_email']) ?></small>
                            <small class="d-block"><i class="bi bi-phone me-2"></i><?= htmlspecialchars($t['pemilik_hp'] ?: '-') ?></small>
                        </div>
                    </div>

                    <!-- Pembawa -->
                    <?php if ($t['pembawa_nama']): ?>
                        <div class="user-profile-card fade-in-up stagger-3 mt-3" style="--user-color-1: #20c997; --user-color-2: #0dcaf0;">
                            <small class="opacity-75 d-block position-relative" style="z-index: 2;">
                                <i class="bi bi-truck"></i> Pembawa Barang
                            </small>
                            <img src="../assets/img/default.jpg" class="user-avatar" alt="Avatar">
                            <h5 class="fw-bold position-relative" style="z-index: 2;"><?= htmlspecialchars($t['pembawa_nama']) ?></h5>
                            <small class="opacity-90 position-relative" style="z-index: 2;">NPM: <?= htmlspecialchars($t['pembawa_npm']) ?></small>
                            <hr class="border-light my-3 position-relative" style="z-index: 2;">
                            <div class="text-start position-relative" style="z-index: 2;">
                                <small class="d-block"><i class="bi bi-phone me-2"></i><?= htmlspecialchars($t['pembawa_hp'] ?: '-') ?></small>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="info-card fade-in-up stagger-3 mt-3 text-center">
                            <i class="bi bi-person-x" style="font-size: 3rem; color: #adb5bd;"></i>
                            <p class="text-muted mt-2 mb-0">Belum ada pembawa</p>
                        </div>
                    <?php endif; ?>

                    <!-- Rating -->
                    <?php if ($rating): ?>
                        <div class="rating-card mt-3 fade-in-up stagger-4">
                            <div class="position-relative" style="z-index: 2;">
                                <small class="opacity-90 d-block mb-2">
                                    <i class="bi bi-star-fill"></i> Rating & Ulasan
                                </small>
                                <div class="rating-stars mb-2">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <i class="bi bi-star<?= $i <= $rating['rating'] ? '-fill' : '' ?>"></i>
                                    <?php endfor; ?>
                                </div>
                                <p class="mb-2 fst-italic">"<?= htmlspecialchars($rating['komentar'] ?: 'Tanpa komentar') ?>"</p>
                                <small class="opacity-90">
                                    - <?= htmlspecialchars($rating['nama']) ?>
                                </small>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Timestamps -->
                    <div class="info-card fade-in-up stagger-5 mt-3">
                        <div class="info-card-title">
                            <div class="info-card-icon" style="background: linear-gradient(135deg, #6c757d, #495057);">
                                <i class="bi bi-clock"></i>
                            </div>
                            <h6 class="fw-bold mb-0">Timestamp</h6>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Dibuat</span>
                            <span class="info-value small"><?= date('d M Y, H:i', strtotime($t['created_at'])) ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Terakhir Update</span>
                            <span class="info-value small"><?= date('d M Y, H:i', strtotime($t['updated_at'])) ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('sidebarToggle')?.addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
        });
    </script>
</body>
</html>