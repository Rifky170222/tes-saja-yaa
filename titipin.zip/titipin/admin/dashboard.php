<?php
require_once '../config/database.php';
cekLogin();
cekRole('admin');

// Statistik
$total_mahasiswa = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'mahasiswa'")->fetchColumn();
$total_titipan = $pdo->query("SELECT COUNT(*) FROM titipan")->fetchColumn();
$menunggu = $pdo->query("SELECT COUNT(*) FROM titipan WHERE status = 'Menunggu'")->fetchColumn();
$berjalan = $pdo->query("SELECT COUNT(*) FROM titipan WHERE status IN ('Diterima','Barang Diambil','Dalam Perjalanan')")->fetchColumn();
$selesai = $pdo->query("SELECT COUNT(*) FROM titipan WHERE status = 'Selesai'")->fetchColumn();
$dibatalkan = $pdo->query("SELECT COUNT(*) FROM titipan WHERE status = 'Dibatalkan'")->fetchColumn();

// Data chart
$chartData = [
    'Menunggu' => $menunggu,
    'Diterima' => $pdo->query("SELECT COUNT(*) FROM titipan WHERE status = 'Diterima'")->fetchColumn(),
    'Barang Diambil' => $pdo->query("SELECT COUNT(*) FROM titipan WHERE status = 'Barang Diambil'")->fetchColumn(),
    'Dalam Perjalanan' => $pdo->query("SELECT COUNT(*) FROM titipan WHERE status = 'Dalam Perjalanan'")->fetchColumn(),
    'Selesai' => $selesai,
    'Dibatalkan' => $dibatalkan
];

// Aktivitas terbaru
$stmt = $pdo->query("SELECT a.*, u.nama FROM aktivitas a 
                     JOIN users u ON a.user_id = u.id 
                     ORDER BY a.created_at DESC LIMIT 8");
$aktivitas = $stmt->fetchAll();

// Greeting
$hour = date('H');
if ($hour < 12) $greeting = 'Selamat Pagi';
elseif ($hour < 17) $greeting = 'Selamat Siang';
elseif ($hour < 20) $greeting = 'Selamat Sore';
else $greeting = 'Selamat Malam';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

    <div class="bg-blobs">
        <div class="blob blob-1"></div>
        <div class="blob blob-2"></div>
        <div class="blob blob-3"></div>
    </div>

    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <!-- Topbar -->
        <div class="topbar-modern">
            <button class="topbar-icon-btn d-lg-none me-2" id="sidebarToggle">
                <i class="bi bi-list"></i>
            </button>
            <div class="topbar-search d-none d-md-block">
                <i class="bi bi-search"></i>
                <input type="text" placeholder="Cari data...">
            </div>
            <div class="topbar-actions">
                <div class="dropdown">
                    <div class="topbar-user" data-bs-toggle="dropdown">
                        <img src="../assets/img/<?= htmlspecialchars($_SESSION['foto'] ?? 'default.jpg') ?>" alt="Admin">
                        <div class="topbar-user-info d-none d-md-block">
                            <h6><?= htmlspecialchars($_SESSION['nama']) ?></h6>
                            <small>Administrator</small>
                        </div>
                        <i class="bi bi-chevron-down small text-muted"></i>
                    </div>
                    <div class="dropdown-menu dropdown-menu-end dropdown-menu-modern">
                        <a href="../logout.php" class="dropdown-item-modern text-danger" onclick="return confirm('Yakin logout?')">
                            <i class="bi bi-box-arrow-right"></i>
                            <div><div class="fw-semibold small">Logout</div></div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="content-wrapper">
            
            <!-- Welcome Banner -->
            <div class="welcome-banner fade-in-up" style="background: var(--dark-gradient);">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <small class="opacity-75"><?= $greeting ?> 👋 Admin</small>
                        <h2 class="mt-1">Panel Administrator</h2>
                        <p class="mb-3">Kelola sistem TITIPIN dengan mudah. Pantau aktivitas mahasiswa dan transaksi titipan.</p>
                        <div class="d-flex gap-2 flex-wrap">
                            <a href="mahasiswa.php" class="btn btn-light btn-sm fw-semibold">
                                <i class="bi bi-people me-1"></i> Kelola Mahasiswa
                            </a>
                            <a href="laporan.php" class="btn btn-outline-light btn-sm fw-semibold">
                                <i class="bi bi-file-earmark-text me-1"></i> Laporan
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 d-none d-md-block text-end">
                        <img src="https://illustrations.popsy.co/amber/remote-work.svg" alt="Illustration" class="welcome-illustration">
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="row g-3 mb-4">
                <div class="col-xl-2 col-md-4 col-6 fade-in-up stagger-1">
                    <div class="stat-card" style="--card-gradient: linear-gradient(135deg, #0d6efd, #6f42c1);">
                        <div class="stat-icon mb-2"><i class="bi bi-people-fill"></i></div>
                        <h3 class="stat-value counter" data-target="<?= $total_mahasiswa ?>">0</h3>
                        <p class="stat-label">Mahasiswa</p>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4 col-6 fade-in-up stagger-2">
                    <div class="stat-card" style="--card-gradient: linear-gradient(135deg, #0dcaf0, #0d6efd);">
                        <div class="stat-icon mb-2"><i class="bi bi-box-seam-fill"></i></div>
                        <h3 class="stat-value counter" data-target="<?= $total_titipan ?>">0</h3>
                        <p class="stat-label">Total Titipan</p>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4 col-6 fade-in-up stagger-3">
                    <div class="stat-card" style="--card-gradient: linear-gradient(135deg, #ffc107, #fd7e14);">
                        <div class="stat-icon mb-2"><i class="bi bi-hourglass-split"></i></div>
                        <h3 class="stat-value counter" data-target="<?= $menunggu ?>">0</h3>
                        <p class="stat-label">Menunggu</p>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4 col-6 fade-in-up stagger-4">
                    <div class="stat-card" style="--card-gradient: linear-gradient(135deg, #6f42c1, #d63384);">
                        <div class="stat-icon mb-2"><i class="bi bi-truck"></i></div>
                        <h3 class="stat-value counter" data-target="<?= $berjalan ?>">0</h3>
                        <p class="stat-label">Berjalan</p>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4 col-6 fade-in-up stagger-5">
                    <div class="stat-card" style="--card-gradient: linear-gradient(135deg, #20c997, #0dcaf0);">
                        <div class="stat-icon mb-2"><i class="bi bi-check-circle-fill"></i></div>
                        <h3 class="stat-value counter" data-target="<?= $selesai ?>">0</h3>
                        <p class="stat-label">Selesai</p>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4 col-6 fade-in-up stagger-5">
                    <div class="stat-card" style="--card-gradient: linear-gradient(135deg, #dc3545, #fd7e14);">
                        <div class="stat-icon mb-2"><i class="bi bi-x-circle-fill"></i></div>
                        <h3 class="stat-value counter" data-target="<?= $dibatalkan ?>">0</h3>
                        <p class="stat-label">Dibatalkan</p>
                    </div>
                </div>
            </div>

            <!-- Charts & Activity -->
            <div class="row g-3">
                <div class="col-lg-8 fade-in-up stagger-3">
                    <div class="modern-card">
                        <div class="modern-card-header">
                            <h6><i class="bi bi-bar-chart-fill"></i> Statistik Titipan</h6>
                        </div>
                        <div class="modern-card-body">
                            <canvas id="chartStatus" height="110"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 fade-in-up stagger-4">
                    <div class="modern-card h-100">
                        <div class="modern-card-header">
                            <h6><i class="bi bi-activity"></i> Aktivitas Sistem</h6>
                        </div>
                        <div class="modern-card-body">
                            <div class="activity-timeline">
                                <?php foreach ($aktivitas as $a): ?>
                                    <div class="activity-item">
                                        <div class="activity-dot"></div>
                                        <div class="activity-content">
                                            <h6><?= htmlspecialchars($a['nama']) ?></h6>
                                            <small><?= htmlspecialchars($a['aktivitas']) ?></small>
                                            <br><small class="text-muted"><?= date('d M H:i', strtotime($a['created_at'])) ?></small>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="text-center text-muted small mt-4 pb-3">
                <p class="mb-0">&copy; 2026 TITIPIN - Admin Panel</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Sidebar Toggle
        document.getElementById('sidebarToggle')?.addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
        });

        // Counter Animation
        document.querySelectorAll('.counter').forEach(counter => {
            const target = parseInt(counter.getAttribute('data-target'));
            const duration = 1500;
            const step = target / (duration / 16);
            let current = 0;
            const update = () => {
                current += step;
                if (current < target) {
                    counter.textContent = Math.ceil(current);
                    requestAnimationFrame(update);
                } else {
                    counter.textContent = target;
                }
            };
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) { update(); observer.disconnect(); }
                });
            });
            observer.observe(counter);
        });

        // Chart
        const ctx = document.getElementById('chartStatus').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?= json_encode(array_keys($chartData)) ?>,
                datasets: [{
                    label: 'Jumlah Titipan',
                    data: <?= json_encode(array_values($chartData)) ?>,
                    backgroundColor: [
                        'rgba(255, 193, 7, 0.8)',
                        'rgba(13, 202, 240, 0.8)',
                        'rgba(253, 126, 20, 0.8)',
                        'rgba(111, 66, 193, 0.8)',
                        'rgba(32, 201, 151, 0.8)',
                        'rgba(220, 53, 69, 0.8)'
                    ],
                    borderRadius: 10,
                    borderSkipped: false,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { 
                        beginAtZero: true,
                        grid: { color: 'rgba(0,0,0,0.05)' }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
    </script>
</body>
</html>