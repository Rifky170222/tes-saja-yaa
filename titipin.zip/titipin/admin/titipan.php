<?php
require_once '../config/database.php';
cekLogin();
cekRole('admin');

// Handle batal
if (isset($_GET['batal'])) {
    $id = (int)$_GET['batal'];
    $stmt = $pdo->prepare("UPDATE titipan SET status = 'Dibatalkan' WHERE id = ? AND status != 'Selesai'");
    $stmt->execute([$id]);
    logAktivitas($pdo, $_SESSION['user_id'], $id, "Admin membatalkan titipan");
    $_SESSION['success'] = 'Titipan berhasil dibatalkan.';
    header('Location: titipan.php');
    exit;
}

// Handle hapus
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $stmt = $pdo->prepare("DELETE FROM titipan WHERE id = ?");
    $stmt->execute([$id]);
    logAktivitas($pdo, $_SESSION['user_id'], null, "Admin menghapus titipan ID $id");
    $_SESSION['success'] = 'Titipan berhasil dihapus.';
    header('Location: titipan.php');
    exit;
}

$status = $_GET['status'] ?? '';
$search = trim($_GET['search'] ?? '');
$where = "1=1";
$params = [];

if ($status !== '') {
    $where .= " AND t.status = ?";
    $params[] = $status;
}
if (!empty($search)) {
    $where .= " AND (t.kode_titipan LIKE ? OR t.nama_barang LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$stmt = $pdo->prepare("SELECT t.*, 
                       p.nama as pemilik_nama,
                       b.nama as pembawa_nama,
                       k.nama_kategori
                       FROM titipan t 
                       JOIN users p ON t.pemilik_id = p.id 
                       LEFT JOIN users b ON t.pembawa_id = b.id 
                       JOIN kategori k ON t.kategori_id = k.id 
                       WHERE $where 
                       ORDER BY t.created_at DESC");
$stmt->execute($params);
$titipan = $stmt->fetchAll();

// Statistik
$stats = [
    'total' => $pdo->query("SELECT COUNT(*) FROM titipan")->fetchColumn(),
    'menunggu' => $pdo->query("SELECT COUNT(*) FROM titipan WHERE status='Menunggu'")->fetchColumn(),
    'berjalan' => $pdo->query("SELECT COUNT(*) FROM titipan WHERE status IN ('Diterima','Barang Diambil','Dalam Perjalanan')")->fetchColumn(),
    'selesai' => $pdo->query("SELECT COUNT(*) FROM titipan WHERE status='Selesai'")->fetchColumn(),
];

$status_config = [
    'Menunggu' => ['color' => '#ffc107', 'icon' => 'hourglass-split'],
    'Diterima' => ['color' => '#0dcaf0', 'icon' => 'check-circle'],
    'Barang Diambil' => ['color' => '#fd7e14', 'icon' => 'box'],
    'Dalam Perjalanan' => ['color' => '#6f42c1', 'icon' => 'truck'],
    'Selesai' => ['color' => '#20c997', 'icon' => 'check-circle-fill'],
    'Dibatalkan' => ['color' => '#dc3545', 'icon' => 'x-circle-fill'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Semua Titipan - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .page-header {
            background: linear-gradient(135deg, #6f42c1 0%, #d63384 100%);
            border-radius: 24px;
            padding: 2rem;
            color: white;
            margin-bottom: 1.5rem;
            position: relative;
            overflow: hidden;
        }
        .page-header::before {
            content: '';
            position: absolute;
            top: -50%; right: -10%;
            width: 300px; height: 300px;
            background: radial-gradient(circle, rgba(255,255,255,0.15), transparent 70%);
            border-radius: 50%;
        }
        .stat-pill {
            background: rgba(255,255,255,0.15);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 0.8rem 1.2rem;
            display: inline-flex;
            align-items: center;
            gap: 0.8rem;
        }
        .stat-pill-icon {
            width: 40px; height: 40px;
            background: rgba(255,255,255,0.25);
            border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
        }
        .status-filter-pills {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        .status-pill {
            padding: 8px 18px;
            border-radius: 20px;
            border: 2px solid #e9ecef;
            background: white;
            font-size: 0.85rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            color: #495057;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .status-pill:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-sm);
        }
        .status-pill.active {
            color: white;
            border-color: transparent;
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }
        .status-pill .count {
            background: rgba(0,0,0,0.1);
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.75rem;
        }
        .status-pill.active .count {
            background: rgba(255,255,255,0.3);
        }
        .titipan-row {
            background: white;
            border-radius: 16px;
            padding: 1.2rem 1.5rem;
            border: 1px solid rgba(0,0,0,0.04);
            box-shadow: var(--shadow-sm);
            margin-bottom: 1rem;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
            animation: slideIn 0.5s ease-out backwards;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .titipan-row::before {
            content: '';
            position: absolute;
            left: 0; top: 0; bottom: 0;
            width: 5px;
            background: var(--status-color);
        }
        .titipan-row:hover {
            transform: translateX(5px);
            box-shadow: var(--shadow-md);
        }
        .status-badge-modern {
            padding: 5px 14px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .kode-badge {
            background: linear-gradient(135deg, rgba(13,110,253,0.1), rgba(111,66,193,0.1));
            color: #0d6efd;
            padding: 4px 12px;
            border-radius: 8px;
            font-size: 0.8rem;
            font-weight: 600;
            font-family: 'Courier New', monospace;
        }
        .user-chip {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 10px 4px 4px;
            background: #f8f9fa;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        .user-chip img {
            width: 22px; height: 22px;
            border-radius: 50%;
            object-fit: cover;
        }
        .info-chip {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-size: 0.8rem;
            color: #6c757d;
        }
        .search-modern {
            position: relative;
        }
        .search-modern input {
            padding: 12px 16px 12px 44px;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            width: 100%;
            background: white;
            transition: all 0.3s;
        }
        .search-modern input:focus {
            border-color: #6f42c1;
            box-shadow: 0 0 0 4px rgba(111, 66, 193, 0.1);
            outline: none;
        }
        .search-modern i {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #adb5bd;
        }
        .action-btn {
            width: 36px; height: 36px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center; justify-content: center;
            border: none;
            transition: all 0.3s;
            text-decoration: none;
        }
        .action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }
        .btn-view { background: rgba(13, 110, 253, 0.1); color: #0d6efd; }
        .btn-cancel { background: rgba(253, 126, 20, 0.1); color: #fd7e14; }
        .btn-delete { background: rgba(220, 53, 69, 0.1); color: #dc3545; }
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
        }
        .empty-state-icon {
            width: 120px; height: 120px;
            margin: 0 auto 1.5rem;
            background: linear-gradient(135deg, rgba(111,66,193,0.1), rgba(214,51,132,0.1));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            animation: bounce 2s infinite;
        }
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
    </style>
</head>
<body>
    <div class="bg-blobs">
        <div class="blob blob-1"></div>
        <div class="blob blob-2"></div>
        <div class="blob blob-3"></div>
    </div>

    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <div class="topbar-modern">
            <button class="topbar-icon-btn d-lg-none me-2" id="sidebarToggle">
                <i class="bi bi-list"></i>
            </button>
            <div class="topbar-search d-none d-md-block">
                <i class="bi bi-search"></i>
                <input type="text" placeholder="Cari data...">
            </div>
            <div class="topbar-actions">
                <div class="dropdown">
                    <div class="topbar-user" data-bs-toggle="dropdown">
                        <img src="../assets/img/<?= htmlspecialchars($_SESSION['foto'] ?? 'default.jpg') ?>" alt="Admin">
                        <div class="topbar-user-info d-none d-md-block">
                            <h6><?= htmlspecialchars($_SESSION['nama']) ?></h6>
                            <small>Administrator</small>
                        </div>
                        <i class="bi bi-chevron-down small text-muted"></i>
                    </div>
                    <div class="dropdown-menu dropdown-menu-end dropdown-menu-modern">
                        <a href="../logout.php" class="dropdown-item-modern text-danger">
                            <i class="bi bi-box-arrow-right"></i>
                            <div><div class="fw-semibold small">Logout</div></div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="content-wrapper">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" style="border-radius: 12px; border: none;">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= htmlspecialchars($_SESSION['success']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <!-- Page Header -->
            <div class="page-header fade-in-up">
                <div class="row align-items-center position-relative" style="z-index: 2;">
                    <div class="col-md-8">
                        <small class="opacity-75"><i class="bi bi-box-seam-fill me-1"></i> Manajemen Titipan</small>
                        <h2 class="fw-bold mt-1 mb-2">Semua Titipan</h2>
                        <p class="mb-0 opacity-90">Pantau dan kelola seluruh transaksi titipan di sistem</p>
                    </div>
                    <div class="col-md-4 text-md-end mt-3 mt-md-0">
                        <div class="d-inline-flex gap-2 flex-wrap justify-content-md-end">
                            <div class="stat-pill">
                                <div class="stat-pill-icon"><i class="bi bi-box-seam"></i></div>
                                <div>
                                    <small class="d-block opacity-75" style="font-size: 0.7rem;">Total</small>
                                    <strong><?= $stats['total'] ?></strong>
                                </div>
                            </div>
                            <div class="stat-pill">
                                <div class="stat-pill-icon"><i class="bi bi-check-circle"></i></div>
                                <div>
                                    <small class="d-block opacity-75" style="font-size: 0.7rem;">Selesai</small>
                                    <strong><?= $stats['selesai'] ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Search & Filter -->
            <div class="modern-card mb-4 fade-in-up stagger-1">
                <div class="modern-card-body">
                    <form method="GET" class="row g-3 align-items-end">
                        <div class="col-md-5">
                            <label class="form-label small fw-semibold">
                                <i class="bi bi-search text-primary"></i> Pencarian
                            </label>
                            <div class="search-modern">
                                <i class="bi bi-search"></i>
                                <input type="text" name="search" placeholder="Cari kode titipan atau nama barang..." 
                                       value="<?= htmlspecialchars($search) ?>">
                            </div>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label small fw-semibold">
                                <i class="bi bi-funnel text-primary"></i> Filter Status
                            </label>
                            <div class="status-filter-pills">
                                <a href="titipan.php" class="status-pill <?= $status==''?'active':'' ?>" 
                                   style="<?= $status==''?'background: linear-gradient(135deg, #0d6efd, #6f42c1);':'' ?>">
                                    Semua <span class="count"><?= $stats['total'] ?></span>
                                </a>
                                <a href="?status=Menunggu" class="status-pill <?= $status=='Menunggu'?'active':'' ?>"
                                   style="<?= $status=='Menunggu'?'background: #ffc107;':'' ?>">
                                    Menunggu <span class="count"><?= $stats['menunggu'] ?></span>
                                </a>
                                <a href="?status=Selesai" class="status-pill <?= $status=='Selesai'?'active':'' ?>"
                                   style="<?= $status=='Selesai'?'background: #20c997;':'' ?>">
                                    Selesai <span class="count"><?= $stats['selesai'] ?></span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-gradient w-100">
                                <i class="bi bi-funnel-fill me-1"></i> Terapkan
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Titipan List -->
            <?php if (empty($titipan)): ?>
                <div class="modern-card">
                    <div class="empty-state">
                        <div class="empty-state-icon">
                            <i class="bi bi-box-seam" style="font-size: 3rem; color: #6f42c1;"></i>
                        </div>
                        <h5 class="fw-bold">Tidak ada titipan</h5>
                        <p class="text-muted">Belum ada titipan yang sesuai dengan filter Anda</p>
                        <a href="titipan.php" class="btn btn-gradient">
                            <i class="bi bi-arrow-clockwise me-1"></i> Reset Filter
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <div>
                    <?php foreach ($titipan as $i => $t): 
                        $config = $status_config[$t['status']] ?? ['color' => '#0d6efd', 'icon' => 'box'];
                    ?>
                        <div class="titipan-row" style="--status-color: <?= $config['color'] ?>; animation-delay: <?= $i * 0.05 ?>s;">
                            <div class="row align-items-center g-3">
                                <div class="col-lg-4">
                                    <div class="d-flex align-items-center gap-3">
                                        <div style="width: 50px; height: 50px; border-radius: 12px; background: <?= $config['color'] ?>20; display: flex; align-items: center; justify-content: center;">
                                            <i class="bi bi-<?= $config['icon'] ?>" style="font-size: 1.3rem; color: <?= $config['color'] ?>;"></i>
                                        </div>
                                        <div class="flex-grow-1 min-w-0">
                                            <span class="kode-badge d-inline-block mb-1"><?= htmlspecialchars($t['kode_titipan']) ?></span>
                                            <h6 class="fw-bold mb-1 text-truncate"><?= htmlspecialchars($t['nama_barang']) ?></h6>
                                            <small class="text-muted">
                                                <i class="bi bi-tag"></i> <?= htmlspecialchars($t['nama_kategori']) ?>
                                                <span class="mx-1">•</span>
                                                <i class="bi bi-box"></i> <?= $t['jumlah'] ?> pcs
                                            </small>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-2">
                                    <small class="text-muted d-block mb-1">Pemilik</small>
                                    <span class="user-chip">
                                        <i class="bi bi-person-fill text-primary"></i>
                                        <?= htmlspecialchars($t['pemilik_nama']) ?>
                                    </span>
                                </div>

                                <div class="col-lg-2">
                                    <small class="text-muted d-block mb-1">Pembawa</small>
                                    <?php if ($t['pembawa_nama']): ?>
                                        <span class="user-chip">
                                            <i class="bi bi-truck text-success"></i>
                                            <?= htmlspecialchars($t['pembawa_nama']) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted small fst-italic">Belum ada</span>
                                    <?php endif; ?>
                                </div>

                                <div class="col-lg-2">
                                    <small class="text-muted d-block mb-1">
                                        <i class="bi bi-geo-alt"></i> Tujuan
                                    </small>
                                    <small class="fw-semibold text-truncate d-block"><?= htmlspecialchars($t['lokasi_tujuan']) ?></small>
                                </div>

                                <div class="col-lg-2">
                                    <span class="status-badge-modern" style="background: <?= $config['color'] ?>20; color: <?= $config['color'] ?>;">
                                        <i class="bi bi-<?= $config['icon'] ?>"></i>
                                        <?= htmlspecialchars($t['status']) ?>
                                    </span>
                                    <div class="mt-2">
                                        <small class="text-muted">
                                            <i class="bi bi-cash"></i> <?= number_format($t['biaya_jasa'], 0, ',', '.') ?>
                                        </small>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex gap-2 mt-3 pt-3 border-top justify-content-end">
                                <a href="detail_titipan.php?id=<?= $t['id'] ?>" class="action-btn btn-view" title="Detail">
                                    <i class="bi bi-eye-fill"></i>
                                </a>
                                <?php if ($t['status'] != 'Selesai' && $t['status'] != 'Dibatalkan'): ?>
                                    <a href="?batal=<?= $t['id'] ?>" class="action-btn btn-cancel" 
                                       onclick="return confirm('Batalkan titipan ini?')" title="Batalkan">
                                        <i class="bi bi-x-circle-fill"></i>
                                    </a>
                                <?php endif; ?>
                                <a href="?hapus=<?= $t['id'] ?>" class="action-btn btn-delete" 
                                   onclick="return confirm('Hapus titipan ini secara permanen?')" title="Hapus">
                                    <i class="bi bi-trash-fill"></i>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('sidebarToggle')?.addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
        });
    </script>
</body>
</html>