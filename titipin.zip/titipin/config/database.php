<?php
// config/database.php
session_start();

// Konfigurasi database
$host = 'localhost';
$dbname = 'titipin_db';
$username = 'root';
$password = '';

// Koneksi PDO
try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}

// Fungsi helper: cek login
function cekLogin() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ../login.php');
        exit;
    }
}

// Fungsi helper: cek role
function cekRole($role) {
    if ($_SESSION['role'] !== $role) {
        header('Location: ../index.php');
        exit;
    }
}

// Fungsi helper: escape HTML
function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

// Fungsi helper: format tanggal
function formatTanggal($tanggal) {
    return date('d M Y', strtotime($tanggal));
}

// Fungsi helper: format rupiah
function formatRupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

// Fungsi helper: log aktivitas
function logAktivitas($pdo, $user_id, $titipan_id, $aktivitas) {
    $stmt = $pdo->prepare("INSERT INTO aktivitas (user_id, titipan_id, aktivitas) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $titipan_id, $aktivitas]);
}

// Fungsi helper: generate kode titipan
function generateKodeTitipan($pdo) {
    $tanggal = date('Ymd');
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM titipan WHERE kode_titipan LIKE ?");
    $stmt->execute(["TIP-$tanggal-%"]);
    $row = $stmt->fetch();
    $nomor = str_pad($row['total'] + 1, 4, '0', STR_PAD_LEFT);
    return "TIP-$tanggal-$nomor";
}

// Fungsi helper: update rating user
function updateRatingUser($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT AVG(rating) as avg_rating FROM rating WHERE penerima_id = ?");
    $stmt->execute([$user_id]);
    $row = $stmt->fetch();
    $avg = $row['avg_rating'] ?? 0;
    $update = $pdo->prepare("UPDATE users SET rating = ? WHERE id = ?");
    $update->execute([$avg, $user_id]);
}
?>