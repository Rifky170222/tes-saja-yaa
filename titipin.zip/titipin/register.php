<?php
require_once 'config/database.php';

if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$errors = [];
$success = '';
$old = ['nama'=>'', 'npm'=>'', 'email'=>'', 'no_hp'=>'', 'prodi'=>'', 'kelas'=>''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $npm = trim($_POST['npm'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $no_hp = trim($_POST['no_hp'] ?? '');
    $password = $_POST['password'] ?? '';
    $konfirmasi = $_POST['konfirmasi'] ?? '';
    $prodi = trim($_POST['prodi'] ?? '');
    $kelas = trim($_POST['kelas'] ?? '');
    
    $old = compact('nama', 'npm', 'email', 'no_hp', 'prodi', 'kelas');
    
    if (empty($nama) || empty($npm) || empty($email) || empty($no_hp) || empty($password) || empty($konfirmasi) || empty($prodi) || empty($kelas)) {
        $errors[] = 'Semua field wajib diisi.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Format email tidak valid.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password minimal 6 karakter.';
    }
    if ($password !== $konfirmasi) {
        $errors[] = 'Password dan konfirmasi password tidak sama.';
    }
    
    $stmt = $pdo->prepare("SELECT id FROM users WHERE npm = ?");
    $stmt->execute([$npm]);
    if ($stmt->fetch()) {
        $errors[] = 'NPM sudah terdaftar.';
    }
    
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        $errors[] = 'Email sudah terdaftar.';
    }
    
    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (nama, npm, email, password, no_hp, prodi, kelas, role) VALUES (?, ?, ?, ?, ?, ?, ?, 'mahasiswa')");
        
        try {
            $stmt->execute([$nama, $npm, $email, $hash, $no_hp, $prodi, $kelas]);
            $user_id = $pdo->lastInsertId();
            logAktivitas($pdo, $user_id, null, 'Registrasi akun baru');
            
            $success = 'Registrasi berhasil! Silakan login.';
            $old = ['nama'=>'', 'npm'=>'', 'email'=>'', 'no_hp'=>'', 'prodi'=>'', 'kelas'=>''];
        } catch (Exception $e) {
            $errors[] = 'Terjadi kesalahan: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - TITIPIN</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <!-- Google Fonts: Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- AOS Animation -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #0d6efd 0%, #0043a8 100%);
            --accent-gradient: linear-gradient(135deg, #6f42c1 0%, #0d6efd 100%);
            --glass-bg: rgba(255, 255, 255, 0.88);
        }

        * {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #eef2ff 0%, #f8f9fc 50%, #fff5eb 100%);
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        /* ========== ANIMATED BACKGROUND ========== */
        .blob {
            position: fixed;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.35;
            z-index: 0;
            pointer-events: none;
        }

        .blob-1 {
            width: 500px;
            height: 500px;
            background: #0d6efd;
            top: -150px;
            right: -100px;
            animation: blobMove1 25s infinite ease-in-out;
        }

        .blob-2 {
            width: 400px;
            height: 400px;
            background: #6f42c1;
            bottom: -100px;
            left: -100px;
            animation: blobMove2 20s infinite ease-in-out;
        }

        .blob-3 {
            width: 300px;
            height: 300px;
            background: #ffc107;
            top: 40%;
            left: 30%;
            animation: blobMove3 22s infinite ease-in-out;
        }

        .blob-4 {
            width: 250px;
            height: 250px;
            background: #20c997;
            bottom: 20%;
            right: 20%;
            animation: blobMove1 18s infinite ease-in-out reverse;
        }

        @keyframes blobMove1 {
            0%, 100% { transform: translate(0, 0) scale(1) rotate(0deg); }
            25% { transform: translate(60px, -40px) scale(1.1) rotate(90deg); }
            50% { transform: translate(-30px, 60px) scale(0.95) rotate(180deg); }
            75% { transform: translate(40px, 30px) scale(1.05) rotate(270deg); }
        }

        @keyframes blobMove2 {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(70px, -60px) scale(1.15); }
            66% { transform: translate(-50px, 40px) scale(0.9); }
        }

        @keyframes blobMove3 {
            0%, 100% { transform: translate(0, 0) scale(1) rotate(0deg); }
            50% { transform: translate(-80px, 50px) scale(1.2) rotate(180deg); }
        }

        /* ========== PARTICLES ========== */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .particle {
            position: absolute;
            width: 6px;
            height: 6px;
            background: rgba(13, 110, 253, 0.3);
            border-radius: 50%;
            animation: particleRise linear infinite;
        }

        @keyframes particleRise {
            0% {
                transform: translateY(100vh) scale(0);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-10vh) scale(1);
                opacity: 0;
            }
        }

        /* ========== MAIN WRAPPER ========== */
        .register-wrapper {
            position: relative;
            z-index: 1;
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 2rem 0;
        }

        /* ========== LEFT BRANDING ========== */
        .branding-side {
            background: var(--accent-gradient);
            border-radius: 30px;
            padding: 3rem 2.5rem;
            color: white;
            position: relative;
            overflow: hidden;
            min-height: 680px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .branding-side::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.08) 0%, transparent 60%);
            animation: rotateBg 25s linear infinite;
        }

        .branding-side::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -30%;
            width: 150%;
            height: 150%;
            background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 50%);
            animation: rotateBg 35s linear infinite reverse;
        }

        @keyframes rotateBg {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .branding-content {
            position: relative;
            z-index: 2;
        }

        .brand-logo {
            font-size: 1.8rem;
            font-weight: 800;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
        }

        .brand-logo i {
            background: white;
            color: #6f42c1;
            padding: 10px;
            border-radius: 12px;
            margin-right: 12px;
            font-size: 1.4rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .branding-title {
            font-size: 2rem;
            font-weight: 700;
            line-height: 1.3;
            margin-bottom: 1rem;
        }

        .branding-subtitle {
            font-size: 0.95rem;
            opacity: 0.9;
            line-height: 1.7;
            margin-bottom: 1.5rem;
        }

        .branding-illustration {
            position: relative;
            z-index: 2;
            text-align: center;
            margin: 1rem 0;
        }

        .branding-illustration img {
            max-width: 85%;
            height: auto;
            filter: drop-shadow(0 20px 40px rgba(0,0,0,0.2));
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            25% { transform: translateY(-15px) rotate(1deg); }
            75% { transform: translateY(5px) rotate(-1deg); }
        }

        .step-list {
            list-style: none;
            padding: 0;
            position: relative;
            z-index: 2;
        }

        .step-list li {
            display: flex;
            align-items: center;
            margin-bottom: 0.8rem;
            font-size: 0.9rem;
        }

        .step-number {
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(10px);
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.85rem;
            margin-right: 12px;
            flex-shrink: 0;
            border: 1px solid rgba(255,255,255,0.3);
        }

        /* ========== RIGHT FORM ========== */
        .form-side {
            padding: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .register-card {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.6);
            border-radius: 25px;
            padding: 2.5rem 2rem;
            box-shadow: 0 20px 60px rgba(111, 66, 193, 0.08),
                        0 4px 20px rgba(0,0,0,0.04);
            width: 100%;
            max-width: 560px;
            animation: cardAppear 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        @keyframes cardAppear {
            from {
                opacity: 0;
                transform: translateY(40px) scale(0.95);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .register-header {
            text-align: center;
            margin-bottom: 1.8rem;
        }

        .register-header h2 {
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 0.3rem;
            font-size: 1.6rem;
        }

        .register-header p {
            color: #6c757d;
            font-size: 0.9rem;
        }

        /* ========== FORM INPUTS ========== */
        .input-group-custom {
            position: relative;
            margin-bottom: 1.2rem;
        }

        .input-group-custom .input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #adb5bd;
            font-size: 1rem;
            z-index: 3;
            transition: all 0.3s ease;
        }

        .input-group-custom .form-control {
            padding: 12px 16px 12px 44px;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            font-size: 0.9rem;
            background: white;
            transition: all 0.3s ease;
            height: auto;
        }

        .input-group-custom .form-control:focus {
            border-color: #6f42c1;
            box-shadow: 0 0 0 4px rgba(111, 66, 193, 0.1);
            outline: none;
        }

        .input-group-custom .form-control:focus ~ .input-icon {
            color: #6f42c1;
            transform: translateY(-50%) scale(1.15);
        }

        .input-group-custom .form-control.is-invalid {
            border-color: #dc3545;
        }

        .input-group-custom label {
            font-size: 0.82rem;
            font-weight: 600;
            color: #495057;
            margin-bottom: 4px;
            display: block;
        }

        .toggle-password {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #adb5bd;
            z-index: 3;
            transition: color 0.3s;
        }

        .toggle-password:hover {
            color: #6f42c1;
        }

        /* ========== PASSWORD STRENGTH ========== */
        .password-strength {
            margin-top: 6px;
        }

        .strength-bar {
            height: 4px;
            border-radius: 4px;
            background: #e9ecef;
            overflow: hidden;
            margin-bottom: 4px;
        }

        .strength-fill {
            height: 100%;
            border-radius: 4px;
            width: 0%;
            transition: all 0.4s ease;
        }

        .strength-text {
            font-size: 0.75rem;
            font-weight: 500;
        }

        /* ========== BUTTON ========== */
        .btn-register {
            background: var(--accent-gradient);
            border: none;
            padding: 14px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            color: white;
            width: 100%;
            box-shadow: 0 8px 25px rgba(111, 66, 193, 0.3);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .btn-register::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent);
            transition: left 0.6s;
        }

        .btn-register:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(111, 66, 193, 0.4);
            color: white;
        }

        .btn-register:hover::before {
            left: 100%;
        }

        .btn-register:active {
            transform: translateY(-1px);
        }

        /* ========== ALERTS ========== */
        .alert-custom {
            border: none;
            border-radius: 12px;
            padding: 12px 16px;
            font-size: 0.85rem;
        }

        .alert-error {
            animation: shake 0.5s ease-in-out;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20% { transform: translateX(-8px); }
            40% { transform: translateX(8px); }
            60% { transform: translateX(-5px); }
            80% { transform: translateX(5px); }
        }

        .alert-success-custom {
            animation: popIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        @keyframes popIn {
            from {
                opacity: 0;
                transform: scale(0.8);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* ========== DIVIDER ========== */
        .divider {
            display: flex;
            align-items: center;
            margin: 1.2rem 0;
            color: #adb5bd;
            font-size: 0.82rem;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #e9ecef;
        }

        .divider span {
            padding: 0 1rem;
        }

        /* ========== BACK LINK ========== */
        .back-link {
            display: inline-flex;
            align-items: center;
            color: #6c757d;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s;
        }

        .back-link:hover {
            color: #6f42c1;
            transform: translateX(-5px);
        }

        /* ========== STEP INDICATOR ========== */
        .form-steps {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-bottom: 1.5rem;
        }

        .step-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #e9ecef;
            transition: all 0.3s;
        }

        .step-dot.active {
            background: var(--accent-gradient);
            width: 30px;
            border-radius: 5px;
        }

        /* ========== RESPONSIVE ========== */
        @media (max-width: 991px) {
            .branding-side {
                min-height: auto;
                padding: 2rem;
                margin-bottom: 1rem;
            }
            .branding-title { font-size: 1.6rem; }
            .branding-illustration { display: none; }
            .register-card { padding: 2rem 1.5rem; }
        }

        @media (max-width: 576px) {
            .form-side { padding: 0.5rem; }
            .register-card { padding: 1.5rem 1rem; border-radius: 20px; }
            .register-header h2 { font-size: 1.3rem; }
        }
    </style>
</head>
<body>

    <!-- Animated Background Blobs -->
    <div class="blob blob-1"></div>
    <div class="blob blob-2"></div>
    <div class="blob blob-3"></div>
    <div class="blob blob-4"></div>

    <!-- Floating Particles -->
    <div class="particles" id="particles"></div>

    <div class="register-wrapper">
        <div class="container">
            <div class="row g-4 align-items-center justify-content-center">
                
                <!-- Left Side: Branding -->
                <div class="col-lg-5" data-aos="fade-right" data-aos-duration="1000">
                    <div class="branding-side">
                        <div class="branding-content">
                            <div class="brand-logo">
                                <i class="bi bi-box-seam-fill"></i>
                                TITIPIN
                            </div>
                            <h1 class="branding-title">Bergabung dengan Komunitas Mahasiswa!</h1>
                            <p class="branding-subtitle">
                                Buat akun gratis dan mulai titip barang dengan mudah. 
                                Ribuan mahasiswa sudah mempercayai TITIPIN.
                            </p>
                        </div>

                        <div class="branding-illustration">
                            <img src="https://illustrations.popsy.co/amber/online-shopping.svg" alt="Register Illustration">
                        </div>

                        <ul class="step-list">
                            <li>
                                <span class="step-number">1</span>
                                Daftar akun dengan NPM mahasiswa
                            </li>
                            <li>
                                <span class="step-number">2</span>
                                Buat permintaan titip barang
                            </li>
                            <li>
                                <span class="step-number">3</span>
                                Barang diantar oleh rekan mahasiswa
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- Right Side: Form -->
                <div class="col-lg-7" data-aos="fade-left" data-aos-duration="1000" data-aos-delay="200">
                    <div class="form-side">
                        <div class="register-card">
                            <div class="register-header">
                                <h2>Buat Akun Baru</h2>
                                <p>Isi data diri Anda untuk mulai menggunakan TITIPIN</p>
                            </div>

                            <!-- Step Indicator -->
                            <div class="form-steps">
                                <div class="step-dot active" id="dot1"></div>
                                <div class="step-dot" id="dot2"></div>
                                <div class="step-dot" id="dot3"></div>
                            </div>

                            <!-- Success Alert -->
                            <?php if ($success): ?>
                                <div class="alert alert-success alert-custom alert-success-custom">
                                    <i class="bi bi-check-circle-fill me-2"></i> 
                                    <?= htmlspecialchars($success) ?>
                                    <a href="login.php" class="alert-link fw-bold">Login sekarang →</a>
                                </div>
                            <?php endif; ?>

                            <!-- Error Alert -->
                            <?php if (!empty($errors)): ?>
                                <div class="alert alert-danger alert-custom alert-error">
                                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                                    <ul class="mb-0 ps-3">
                                        <?php foreach ($errors as $err): ?>
                                            <li><?= htmlspecialchars($err) ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <form method="POST" id="registerForm" novalidate>
                                <div class="row g-2">
                                    <!-- Nama Lengkap -->
                                    <div class="col-md-6">
                                        <div class="input-group-custom">
                                            <label>Nama Lengkap</label>
                                            <input type="text" name="nama" class="form-control" 
                                                   placeholder="Nama lengkap" required
                                                   value="<?= htmlspecialchars($old['nama']) ?>">
                                            <i class="bi bi-person input-icon"></i>
                                        </div>
                                    </div>

                                    <!-- NPM -->
                                    <div class="col-md-6">
                                        <div class="input-group-custom">
                                            <label>NPM</label>
                                            <input type="text" name="npm" class="form-control" 
                                                   placeholder="Contoh: 20230001" required
                                                   value="<?= htmlspecialchars($old['npm']) ?>">
                                            <i class="bi bi-card-text input-icon"></i>
                                        </div>
                                    </div>

                                    <!-- Email -->
                                    <div class="col-md-6">
                                        <div class="input-group-custom">
                                            <label>Email</label>
                                            <input type="email" name="email" class="form-control" 
                                                   placeholder="email@contoh.com" required
                                                   value="<?= htmlspecialchars($old['email']) ?>">
                                            <i class="bi bi-envelope input-icon"></i>
                                        </div>
                                    </div>

                                    <!-- No HP -->
                                    <div class="col-md-6">
                                        <div class="input-group-custom">
                                            <label>Nomor HP</label>
                                            <input type="tel" name="no_hp" class="form-control" 
                                                   placeholder="08xxxxxxxxxx" required
                                                   value="<?= htmlspecialchars($old['no_hp']) ?>">
                                            <i class="bi bi-phone input-icon"></i>
                                        </div>
                                    </div>

                                    <!-- Prodi -->
                                    <div class="col-md-6">
                                        <div class="input-group-custom">
                                            <label>Program Studi</label>
                                            <input type="text" name="prodi" class="form-control" 
                                                   placeholder="Teknik Informatika" required
                                                   value="<?= htmlspecialchars($old['prodi']) ?>">
                                            <i class="bi bi-mortarboard input-icon"></i>
                                        </div>
                                    </div>

                                    <!-- Kelas -->
                                    <div class="col-md-6">
                                        <div class="input-group-custom">
                                            <label>Kelas</label>
                                            <input type="text" name="kelas" class="form-control" 
                                                   placeholder="TI-3A" required
                                                   value="<?= htmlspecialchars($old['kelas']) ?>">
                                            <i class="bi bi-building input-icon"></i>
                                        </div>
                                    </div>

                                    <!-- Password -->
                                    <div class="col-md-6">
                                        <div class="input-group-custom">
                                            <label>Password</label>
                                            <input type="password" name="password" class="form-control" 
                                                   id="password" placeholder="Min. 6 karakter" required>
                                            <i class="bi bi-lock input-icon"></i>
                                            <i class="bi bi-eye-slash toggle-password" data-target="password"></i>
                                            <div class="password-strength" id="strengthContainer">
                                                <div class="strength-bar">
                                                    <div class="strength-fill" id="strengthFill"></div>
                                                </div>
                                                <small class="strength-text" id="strengthText"></small>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Konfirmasi Password -->
                                    <div class="col-md-6">
                                        <div class="input-group-custom">
                                            <label>Konfirmasi Password</label>
                                            <input type="password" name="konfirmasi" class="form-control" 
                                                   id="konfirmasi" placeholder="Ulangi password" required>
                                            <i class="bi bi-shield-lock input-icon"></i>
                                            <i class="bi bi-eye-slash toggle-password" data-target="konfirmasi"></i>
                                            <small class="text-muted d-none" id="matchText"></small>
                                        </div>
                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <button type="submit" class="btn btn-register mt-3" id="btnRegister">
                                    <i class="bi bi-person-plus-fill me-2"></i> Daftar Sekarang
                                </button>

                                <div class="divider">
                                    <span>Sudah punya akun?</span>
                                </div>

                                <a href="login.php" class="btn btn-outline-secondary w-100" 
                                   style="border-radius: 12px; padding: 12px; font-weight: 600; border-width: 2px;">
                                    <i class="bi bi-box-arrow-in-right me-2"></i> Masuk ke Akun
                                </a>
                            </form>
                        </div>

                        <div class="text-center mt-3">
                            <a href="index.php" class="back-link">
                                <i class="bi bi-arrow-left me-2"></i> Kembali ke Beranda
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    
    <script>
        // ========== AOS INIT ==========
        AOS.init({
            once: true,
            offset: 50,
            duration: 800,
        });

        // ========== PARTICLES GENERATOR ==========
        (function createParticles() {
            const container = document.getElementById('particles');
            const count = 20;
            for (let i = 0; i < count; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                particle.style.left = Math.random() * 100 + '%';
                particle.style.width = (Math.random() * 6 + 3) + 'px';
                particle.style.height = particle.style.width;
                particle.style.animationDuration = (Math.random() * 15 + 10) + 's';
                particle.style.animationDelay = (Math.random() * 10) + 's';
                particle.style.background = `rgba(${Math.random() > 0.5 ? '111, 66, 193' : '13, 110, 253'}, ${Math.random() * 0.3 + 0.1})`;
                container.appendChild(particle);
            }
        })();

        // ========== TOGGLE PASSWORD ==========
        document.querySelectorAll('.toggle-password').forEach(toggle => {
            toggle.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target');
                const input = document.getElementById(targetId);
                const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
                input.setAttribute('type', type);
                this.classList.toggle('bi-eye');
                this.classList.toggle('bi-eye-slash');
            });
        });

        // ========== PASSWORD STRENGTH ==========
        const passwordInput = document.getElementById('password');
        const strengthFill = document.getElementById('strengthFill');
        const strengthText = document.getElementById('strengthText');

        passwordInput.addEventListener('input', function() {
            const val = this.value;
            let score = 0;

            if (val.length >= 6) score++;
            if (val.length >= 8) score++;
            if (/[a-z]/.test(val) && /[A-Z]/.test(val)) score++;
            if (/\d/.test(val)) score++;
            if (/[^a-zA-Z0-9]/.test(val)) score++;

            const levels = [
                { width: '0%', color: '#e9ecef', text: '' },
                { width: '20%', color: '#dc3545', text: 'Sangat Lemah' },
                { width: '40%', color: '#fd7e14', text: 'Lemah' },
                { width: '60%', color: '#ffc107', text: 'Cukup' },
                { width: '80%', color: '#20c997', text: 'Kuat' },
                { width: '100%', color: '#198754', text: 'Sangat Kuat 💪' }
            ];

            const level = levels[score];
            strengthFill.style.width = level.width;
            strengthFill.style.background = level.color;
            strengthText.textContent = level.text;
            strengthText.style.color = level.color;

            // Update step dots
            updateStepDots();
        });

        // ========== PASSWORD MATCH CHECK ==========
        const konfirmasiInput = document.getElementById('konfirmasi');
        const matchText = document.getElementById('matchText');

        konfirmasiInput.addEventListener('input', function() {
            const pass = passwordInput.value;
            const conf = this.value;

            if (conf.length === 0) {
                matchText.classList.add('d-none');
                this.classList.remove('is-invalid', 'is-valid');
                return;
            }

            matchText.classList.remove('d-none');
            if (pass === conf) {
                matchText.textContent = '✓ Password cocok';
                matchText.className = 'text-success';
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
            } else {
                matchText.textContent = '✗ Password tidak cocok';
                matchText.className = 'text-danger';
                this.classList.remove('is-valid');
                this.classList.add('is-invalid');
            }
        });

        // ========== STEP DOTS ANIMATION ==========
        function updateStepDots() {
            const nama = document.querySelector('input[name="nama"]').value;
            const npm = document.querySelector('input[name="npm"]').value;
            const email = document.querySelector('input[name="email"]').value;
            const pass = passwordInput.value;

            const dot1 = document.getElementById('dot1');
            const dot2 = document.getElementById('dot2');
            const dot3 = document.getElementById('dot3');

            // Step 1: Data pribadi
            if (nama && npm && email) {
                dot1.classList.add('active');
            } else {
                dot1.classList.remove('active');
            }

            // Step 2: Prodi & Kelas
            const prodi = document.querySelector('input[name="prodi"]').value;
            const kelas = document.querySelector('input[name="kelas"]').value;
            if (prodi && kelas) {
                dot2.classList.add('active');
            } else {
                dot2.classList.remove('active');
            }

            // Step 3: Password
            if (pass.length >= 6) {
                dot3.classList.add('active');
            } else {
                dot3.classList.remove('active');
            }
        }

        // Listen to all inputs for step dots
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('input', updateStepDots);
        });

        // ========== INPUT FOCUS ANIMATION ==========
        document.querySelectorAll('.input-group-custom .form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.closest('.input-group-custom').style.transform = 'scale(1.02)';
                this.closest('.input-group-custom').style.transition = 'transform 0.3s ease';
            });
            input.addEventListener('blur', function() {
                this.closest('.input-group-custom').style.transform = 'scale(1)';
            });
        });

        // ========== FORM SUBMIT ANIMATION ==========
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const btn = document.getElementById('btnRegister');
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Memproses Registrasi...';
            btn.disabled = true;
            btn.style.opacity = '0.8';
        });

        // ========== INITIAL STEP DOTS ==========
        updateStepDots();
    </script>
</body>
</html>