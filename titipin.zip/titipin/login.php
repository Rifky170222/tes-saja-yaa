<?php
require_once 'config/database.php';

// Jika sudah login, redirect
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: mahasiswa/dashboard.php');
    }
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $error = 'Email dan password wajib diisi.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['nama'] = $user['nama'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['foto'] = $user['foto'];
            
            logAktivitas($pdo, $user['id'], null, 'Login ke sistem');
            
            if ($user['role'] === 'admin') {
                header('Location: admin/dashboard.php');
            } else {
                header('Location: mahasiswa/dashboard.php');
            }
            exit;
        } else {
            $error = 'Email atau password salah.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - TITIPIN</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <!-- Google Fonts: Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- AOS Animation -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #0d6efd 0%, #0043a8 100%);
            --accent-color: #ffc107;
            --glass-bg: rgba(255, 255, 255, 0.85);
        }

        * {
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f0f4ff 0%, #ffffff 100%);
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        /* Animated Background Blobs */
        .blob {
            position: fixed;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.4;
            z-index: 0;
            animation: blobFloat 20s infinite ease-in-out;
        }

        .blob-1 {
            width: 400px;
            height: 400px;
            background: #0d6efd;
            top: -100px;
            left: -100px;
            animation-delay: 0s;
        }

        .blob-2 {
            width: 350px;
            height: 350px;
            background: #ffc107;
            bottom: -100px;
            right: -100px;
            animation-delay: 5s;
        }

        .blob-3 {
            width: 300px;
            height: 300px;
            background: #6f42c1;
            top: 50%;
            left: 50%;
            animation-delay: 10s;
        }

        @keyframes blobFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(50px, -50px) scale(1.1); }
            66% { transform: translate(-30px, 30px) scale(0.9); }
        }

        /* Main Container */
        .login-wrapper {
            position: relative;
            z-index: 1;
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 2rem 0;
        }

        /* Left Side - Branding */
        .branding-side {
            background: var(--primary-gradient);
            border-radius: 30px;
            padding: 3rem 2.5rem;
            color: white;
            position: relative;
            overflow: hidden;
            min-height: 600px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .branding-side::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: rotateBg 30s linear infinite;
        }

        @keyframes rotateBg {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .branding-content {
            position: relative;
            z-index: 2;
        }

        .brand-logo {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
        }

        .brand-logo i {
            background: white;
            color: #0d6efd;
            padding: 10px;
            border-radius: 12px;
            margin-right: 12px;
            font-size: 1.5rem;
        }

        .branding-title {
            font-size: 2.2rem;
            font-weight: 700;
            line-height: 1.3;
            margin-bottom: 1.5rem;
        }

        .branding-subtitle {
            font-size: 1rem;
            opacity: 0.9;
            margin-bottom: 2rem;
            line-height: 1.7;
        }

        .branding-illustration {
            position: relative;
            z-index: 2;
            text-align: center;
            margin: 2rem 0;
        }

        .branding-illustration img {
            max-width: 100%;
            height: auto;
            filter: drop-shadow(0 20px 30px rgba(0,0,0,0.2));
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }

        .feature-list {
            list-style: none;
            padding: 0;
            position: relative;
            z-index: 2;
        }

        .feature-list li {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
            font-size: 0.95rem;
        }

        .feature-list li i {
            background: rgba(255,255,255,0.2);
            padding: 8px;
            border-radius: 50%;
            margin-right: 12px;
            font-size: 0.9rem;
        }

        /* Right Side - Form */
        .form-side {
            padding: 2rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-card {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 25px;
            padding: 3rem 2.5rem;
            box-shadow: 0 20px 60px rgba(13, 110, 253, 0.1);
            width: 100%;
            max-width: 450px;
            animation: slideIn 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .login-header h2 {
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 0.5rem;
        }

        .login-header p {
            color: #6c757d;
            font-size: 0.95rem;
        }

        /* Form Inputs */
        .form-floating-custom {
            position: relative;
            margin-bottom: 1.5rem;
        }

        .form-floating-custom .input-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #0d6efd;
            font-size: 1.1rem;
            z-index: 3;
            transition: all 0.3s;
        }

        .form-floating-custom .form-control {
            padding: 14px 50px 14px 50px;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            font-size: 0.95rem;
            background: white;
            transition: all 0.3s ease;
        }

        .form-floating-custom .form-control:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1);
            outline: none;
        }

        .form-floating-custom .form-control:focus + .input-icon,
        .form-floating-custom .form-control:not(:placeholder-shown) + .input-icon {
            color: #0d6efd;
            transform: translateY(-50%) scale(1.1);
        }

        .toggle-password {
            position: absolute;
            right: 18px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
            z-index: 3;
            transition: color 0.3s;
        }

        .toggle-password:hover {
            color: #0d6efd;
        }

        /* Button */
        .btn-login {
            background: var(--primary-gradient);
            border: none;
            padding: 14px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            color: white;
            width: 100%;
            box-shadow: 0 8px 20px rgba(13, 110, 253, 0.3);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .btn-login::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: left 0.5s;
        }

        .btn-login:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 25px rgba(13, 110, 253, 0.4);
            color: white;
        }

        .btn-login:hover::before {
            left: 100%;
        }

        .btn-login:active {
            transform: translateY(-1px);
        }

        /* Divider */
        .divider {
            display: flex;
            align-items: center;
            margin: 1.5rem 0;
            color: #adb5bd;
            font-size: 0.85rem;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #e9ecef;
        }

        .divider span {
            padding: 0 1rem;
        }

        /* Demo Accounts */
        .demo-accounts {
            background: rgba(13, 110, 253, 0.05);
            border: 1px dashed rgba(13, 110, 253, 0.3);
            border-radius: 12px;
            padding: 1rem;
            font-size: 0.85rem;
        }

        .demo-accounts strong {
            color: #0d6efd;
        }

        .demo-accounts code {
            background: white;
            padding: 2px 8px;
            border-radius: 4px;
            color: #1a1a2e;
            font-size: 0.8rem;
        }

        /* Alert */
        .alert-custom {
            border: none;
            border-radius: 12px;
            padding: 12px 16px;
            font-size: 0.9rem;
            animation: shake 0.5s;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-10px); }
            75% { transform: translateX(10px); }
        }

        /* Back Link */
        .back-link {
            display: inline-flex;
            align-items: center;
            color: #6c757d;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s;
        }

        .back-link:hover {
            color: #0d6efd;
            transform: translateX(-5px);
        }

        /* Responsive */
        @media (max-width: 991px) {
            .branding-side {
                min-height: auto;
                padding: 2rem;
                margin-bottom: 2rem;
            }
            .branding-title { font-size: 1.8rem; }
            .branding-illustration { display: none; }
            .login-card { padding: 2rem 1.5rem; }
        }

        @media (max-width: 576px) {
            .form-side { padding: 1rem; }
            .login-card { padding: 1.5rem; }
        }
    </style>
</head>
<body>

    <!-- Animated Background Blobs -->
    <div class="blob blob-1"></div>
    <div class="blob blob-2"></div>
    <div class="blob blob-3"></div>

    <div class="login-wrapper">
        <div class="container">
            <div class="row g-4 align-items-center">
                
                <!-- Left Side: Branding -->
                <div class="col-lg-6" data-aos="fade-right" data-aos-duration="1000">
                    <div class="branding-side">
                        <div class="branding-content">
                            <div class="brand-logo">
                                <i class="bi bi-box-seam-fill"></i>
                                TITIPIN
                            </div>
                            <h1 class="branding-title">Selamat Datang Kembali!</h1>
                            <p class="branding-subtitle">
                                Titip barang jadi lebih mudah dan aman. Hubungkan dengan mahasiswa lain 
                                yang sedang menuju lokasi yang sama.
                            </p>
                        </div>

                        <div class="branding-illustration">
                            <img src="https://illustrations.popsy.co/amber/man-riding-a-scooter.svg" alt="Illustration">
                        </div>

                        <ul class="feature-list">
                            <li><i class="bi bi-check2"></i> Cepat & Terpercaya</li>
                            <li><i class="bi bi-check2"></i> Sistem Rating Transparan</li>
                            <li><i class="bi bi-check2"></i> Khusus Mahasiswa Terverifikasi</li>
                        </ul>
                    </div>
                </div>

                <!-- Right Side: Form -->
                <div class="col-lg-6" data-aos="fade-left" data-aos-duration="1000" data-aos-delay="200">
                    <div class="form-side">
                        <div class="login-card">
                            <div class="login-header">
                                <h2>Masuk ke Akun</h2>
                                <p>Silakan login untuk melanjutkan</p>
                            </div>

                            <?php if ($error): ?>
                                <div class="alert alert-danger alert-custom">
                                    <i class="bi bi-exclamation-circle me-2"></i> <?= htmlspecialchars($error) ?>
                                </div>
                            <?php endif; ?>

                            <form method="POST" id="loginForm">
                                <!-- Email -->
                                <div class="form-floating-custom">
                                    <input type="email" name="email" class="form-control" id="email" 
                                           placeholder="Email" required
                                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                                    <i class="bi bi-envelope input-icon"></i>
                                </div>

                                <!-- Password -->
                                <div class="form-floating-custom">
                                    <input type="password" name="password" class="form-control" id="password" 
                                           placeholder="Password" required>
                                    <i class="bi bi-lock input-icon"></i>
                                    <i class="bi bi-eye-slash toggle-password" id="togglePassword"></i>
                                </div>

                                <!-- Remember & Forgot -->
                                <div class="d-flex justify-content-between align-items-center mb-4">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="remember">
                                        <label class="form-check-label small" for="remember">Ingat saya</label>
                                    </div>
                                    <a href="#" class="small text-decoration-none text-primary">Lupa password?</a>
                                </div>

                                <!-- Submit Button -->
                                <button type="submit" class="btn btn-login">
                                    <i class="bi bi-box-arrow-in-right me-2"></i> Masuk
                                </button>

                                <div class="divider">
                                    <span>Belum punya akun?</span>
                                </div>

                                <a href="register.php" class="btn btn-outline-primary w-100" style="border-radius: 12px; padding: 12px; font-weight: 600;">
                                    <i class="bi bi-person-plus me-2"></i> Daftar Sekarang
                                </a>
                            </form>

                            <!-- Demo Accounts -->
                            <div class="demo-accounts mt-4">
                                <strong><i class="bi bi-info-circle me-1"></i> Akun Demo:</strong>
                                <div class="mt-2">
                                    <div class="mb-1">
                                        <small>Admin:</small> 
                                        <code>admin@titipin.com</code> / <code>admin123</code>
                                    </div>
                                    <div>
                                        <small>Mahasiswa:</small> 
                                        <code>aditya@titipin.com</code> / <code>mahasiswa123</code>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="text-center mt-4">
                            <a href="index.php" class="back-link">
                                <i class="bi bi-arrow-left me-2"></i> Kembali ke Beranda
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    
    <script>
        // Initialize AOS
        AOS.init({
            once: true,
            offset: 50,
            duration: 800,
        });

        // Toggle Password Visibility
        const togglePassword = document.getElementById('togglePassword');
        const password = document.getElementById('password');

        togglePassword.addEventListener('click', function() {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            
            // Toggle icon
            this.classList.toggle('bi-eye');
            this.classList.toggle('bi-eye-slash');
        });

        // Form submit animation
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const btn = this.querySelector('.btn-login');
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Memproses...';
            btn.disabled = true;
        });

        // Input focus animation
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'scale(1.02)';
                this.parentElement.style.transition = 'transform 0.3s';
            });
            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'scale(1)';
            });
        });
    </script>
</body>
</html>