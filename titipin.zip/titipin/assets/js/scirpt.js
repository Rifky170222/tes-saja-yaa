// TITIPIN - Script Helper

document.addEventListener('DOMContentLoaded', function() {
    
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
    
    // Konfirmasi hapus untuk link dengan data-confirm
    document.querySelectorAll('[data-confirm]').forEach(element => {
        element.addEventListener('click', function(e) {
            const message = this.getAttribute('data-confirm');
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });
    
    // Preview foto sebelum upload
    const fotoInput = document.querySelector('input[name="foto"]');
    if (fotoInput) {
        fotoInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    const preview = document.querySelector('img.rounded-circle');
                    if (preview) preview.src = event.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    // Validasi tanggal batas harus lebih besar dari tanggal pengambilan
    const tglAmbil = document.querySelector('input[name="tanggal_pengambilan"]');
    const batas = document.querySelector('input[name="batas_pengantaran"]');
    
    if (tglAmbil && batas) {
        tglAmbil.addEventListener('change', function() {
            batas.min = this.value;
            if (batas.value < this.value) {
                batas.value = this.value;
            }
        });
    }
    
    // Tooltips
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(el => new bootstrap.Tooltip(el));
    
    console.log('TITIPIN App Loaded ✅');
});