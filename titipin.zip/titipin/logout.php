<?php
require_once 'config/database.php';

if (isset($_SESSION['user_id'])) {
    logAktivitas($pdo, $_SESSION['user_id'], null, 'Logout dari sistem');
}

session_destroy();
header('Location: index.php');
exit;
?>