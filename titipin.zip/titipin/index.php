<?php
require_once 'config/database.php';

// Jika sudah login, redirect ke dashboard sesuai role
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: mahasiswa/dashboard.php');
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TITIPIN - Sistem Titip Barang Antar Mahasiswa</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <!-- Google Fonts: Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- AOS Animation CSS -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #0d6efd 0%, #0043a8 100%);
            --accent-color: #ffc107;
            --glass-bg: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.3);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fc;
            overflow-x: hidden;
        }

        /* Navbar Glassmorphism */
        .navbar-glass {
            background: var(--glass-bg);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border-bottom: 1px solid var(--glass-border);
            transition: all 0.3s ease;
        }

        .navbar-brand {
            font-weight: 800;
            font-size: 1.5rem;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* Hero Section */
        .hero-section {
            background: linear-gradient(135deg, #f0f4ff 0%, #ffffff 100%);
            padding: 120px 0 80px;
            position: relative;
            overflow: hidden;
        }

        .hero-section::before {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 400px;
            height: 400px;
            background: rgba(13, 110, 253, 0.05);
            border-radius: 50%;
            z-index: 0;
        }

        .hero-title {
            font-weight: 800;
            font-size: 3rem;
            line-height: 1.2;
            color: #1a1a2e;
        }

        .hero-title span {
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero-subtitle {
            font-size: 1.15rem;
            color: #6c757d;
            margin-bottom: 2rem;
        }

        /* Floating Animation for Image */
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }

        .floating-img {
            animation: float 6s ease-in-out infinite;
            max-width: 100%;
            height: auto;
            filter: drop-shadow(0 20px 30px rgba(13, 110, 253, 0.15));
        }

        /* Buttons */
        .btn-primary-custom {
            background: var(--primary-gradient);
            border: none;
            padding: 12px 32px;
            border-radius: 50px;
            font-weight: 600;
            box-shadow: 0 8px 20px rgba(13, 110, 253, 0.3);
            transition: all 0.3s ease;
        }

        .btn-primary-custom:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 25px rgba(13, 110, 253, 0.4);
            color: white;
        }

        .btn-outline-custom {
            border: 2px solid #0d6efd;
            color: #0d6efd;
            padding: 10px 30px;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-outline-custom:hover {
            background: #0d6efd;
            color: white;
            transform: translateY(-3px);
        }

        /* Feature Cards */
        .feature-card {
            background: white;
            border-radius: 20px;
            padding: 2.5rem 2rem;
            border: 1px solid rgba(0,0,0,0.05);
            box-shadow: 0 10px 30px rgba(0,0,0,0.03);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            height: 100%;
        }

        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(13, 110, 253, 0.1);
            border-color: rgba(13, 110, 253, 0.2);
        }

        .feature-icon {
            width: 70px;
            height: 70px;
            background: rgba(13, 110, 253, 0.1);
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: #0d6efd;
            margin-bottom: 1.5rem;
            transition: all 0.3s ease;
        }

        .feature-card:hover .feature-icon {
            background: var(--primary-gradient);
            color: white;
            transform: scale(1.1) rotate(5deg);
        }

        /* Stats Section */
        .stats-section {
            background: var(--primary-gradient);
            color: white;
            padding: 60px 0;
        }

        .stat-item h3 {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0;
        }

        /* Footer */
        footer {
            background: #1a1a2e;
            color: #a0a0b0;
            padding: 40px 0;
        }
        
        footer a {
            color: #a0a0b0;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        footer a:hover {
            color: white;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .hero-title { font-size: 2.2rem; }
            .hero-section { padding: 100px 0 60px; text-align: center; }
            .hero-img-container { margin-top: 40px; }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg fixed-top navbar-glass">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-box-seam-fill me-2"></i>TITIPIN
            </a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item"><a class="nav-link fw-medium" href="#cara-kerja">Cara Kerja</a></li>
                    <li class="nav-item"><a class="nav-link fw-medium" href="#keunggulan">Keunggulan</a></li>
                    <li class="nav-item ms-lg-3">
                        <a href="login.php" class="btn btn-outline-custom btn-sm me-2">Login</a>
                    </li>
                    <li class="nav-item">
                        <a href="register.php" class="btn btn-primary-custom btn-sm text-white">Daftar Gratis</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6" data-aos="fade-right" data-aos-duration="1000">
                    <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill mb-3 fw-semibold">
                        🎓 Khusus Mahasiswa
                    </span>
                    <h1 class="hero-title">
                        Titip Barang Jadi <br>
                        <span>Lebih Mudah & Aman</span>
                    </h1>
                    <p class="hero-subtitle mt-3">
                        Butuh titip dokumen, makanan, atau barang dari kampus/kos? 
                        Hubungkan dengan mahasiswa lain yang sedang menuju lokasi yang sama. 
                        Cepat, terpercaya, dan saling menguntungkan.
                    </p>
                    <div class="d-flex gap-3 flex-wrap justify-content-lg-start justify-content-center">
                        <a href="register.php" class="btn btn-primary-custom text-white">
                            <i class="bi bi-rocket-takeoff me-2"></i>Mulai Titip Sekarang
                        </a>
                        <a href="#cara-kerja" class="btn btn-outline-custom">
                            <i class="bi bi-play-circle me-2"></i>Lihat Cara Kerja
                        </a>
                    </div>
                    
                    <div class="mt-4 d-flex align-items-center gap-3 justify-content-lg-start justify-content-center">
                        <div class="d-flex">
                            <img src="https://randomuser.me/api/portraits/men/32.jpg" class="rounded-circle border border-2 border-white" width="40" alt="User">
                            <img src="https://randomuser.me/api/portraits/women/44.jpg" class="rounded-circle border border-2 border-white" width="40" style="margin-left: -15px;" alt="User">
                            <img src="https://randomuser.me/api/portraits/men/85.jpg" class="rounded-circle border border-2 border-white" width="40" style="margin-left: -15px;" alt="User">
                        </div>
                        <div>
                            <div class="text-warning">
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                            </div>
                            <small class="text-muted fw-medium">Dipercaya 500+ Mahasiswa</small>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-6 hero-img-container text-center" data-aos="fade-left" data-aos-duration="1000" data-aos-delay="200">
                    <!-- Ilustrasi Modern (Gratis dari Popsy.co) -->
                    <img src="https://illustrations.popsy.co/amber/delivery.svg" alt="Delivery Illustration" class="floating-img" style="max-width: 500px;">
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-4 mb-4 mb-md-0" data-aos="zoom-in" data-aos-delay="100">
                    <div class="stat-item">
                        <h3>500+</h3>
                        <p class="mb-0 opacity-75">Titipan Berhasil</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4 mb-md-0" data-aos="zoom-in" data-aos-delay="200">
                    <div class="stat-item">
                        <h3>120+</h3>
                        <p class="mb-0 opacity-75">Mahasiswa Aktif</p>
                    </div>
                </div>
                <div class="col-md-4" data-aos="zoom-in" data-aos-delay="300">
                    <div class="stat-item">
                        <h3>4.9/5</h3>
                        <p class="mb-0 opacity-75">Rating Kepuasan</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Cara Kerja Section -->
    <section id="cara-kerja" class="py-5 bg-white">
        <div class="container py-5">
            <div class="text-center mb-5" data-aos="fade-up">
                <h6 class="text-primary fw-bold text-uppercase ls-2">Proses Mudah</h6>
                <h2 class="fw-bold">Bagaimana Cara Kerja <span class="text-primary">TITIPIN</span>?</h2>
                <p class="text-muted mx-auto" style="max-width: 600px;">Hanya dalam 3 langkah sederhana, barang Anda akan sampai ke tujuan dengan aman.</p>
            </div>
            
            <div class="row g-4">
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="feature-card text-center">
                        <div class="feature-icon mx-auto">
                            <i class="bi bi-pencil-square"></i>
                        </div>
                        <h4 class="fw-bold mb-3">1. Buat Permintaan</h4>
                        <p class="text-muted">Isi detail barang, lokasi pengambilan, tujuan, dan estimasi biaya jasa titip yang Anda tawarkan.</p>
                    </div>
                </div>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="feature-card text-center">
                        <div class="feature-icon mx-auto">
                            <i class="bi bi-people-fill"></i>
                        </div>
                        <h4 class="fw-bold mb-3">2. Diterima Pembawa</h4>
                        <p class="text-muted">Mahasiswa lain yang sedang menuju lokasi yang sama akan melihat dan mengambil permintaan Anda.</p>
                    </div>
                </div>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="feature-card text-center">
                        <div class="feature-icon mx-auto">
                            <i class="bi bi-check-circle-fill"></i>
                        </div>
                        <h4 class="fw-bold mb-3">3. Selesai & Rating</h4>
                        <p class="text-muted">Barang sampai dengan aman. Konfirmasi penerimaan dan berikan rating kepada pembawa barang.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Keunggulan Section -->
    <section id="keunggulan" class="py-5" style="background-color: #f8f9fc;">
        <div class="container py-5">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0" data-aos="fade-right">
                    <img src="https://illustrations.popsy.co/amber/remote-work.svg" alt="Keunggulan" class="img-fluid floating-img" style="max-width: 450px;">
                </div>
                <div class="col-lg-6" data-aos="fade-left">
                    <h6 class="text-primary fw-bold text-uppercase">Kenapa Memilih Kami?</h6>
                    <h2 class="fw-bold mb-4">Solusi Titip Barang <br>Terpercaya Antar Mahasiswa</h2>
                    
                    <div class="d-flex mb-4">
                        <div class="flex-shrink-0">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                <i class="bi bi-shield-check fs-4"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5 class="fw-bold">Aman & Terverifikasi</h5>
                            <p class="text-muted mb-0">Semua pengguna adalah mahasiswa terdaftar dengan NPM yang valid, menjamin keamanan barang Anda.</p>
                        </div>
                    </div>
                    
                    <div class="d-flex mb-4">
                        <div class="flex-shrink-0">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                <i class="bi bi-lightning-charge-fill fs-4"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5 class="fw-bold">Cepat & Efisien</h5>
                            <p class="text-muted mb-0">Manfaatkan perjalanan yang sudah ada. Tidak perlu menunggu kurir, barang langsung diantar oleh rekan mahasiswa.</p>
                        </div>
                    </div>
                    
                    <div class="d-flex">
                        <div class="flex-shrink-0">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                <i class="bi bi-star-fill fs-4"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5 class="fw-bold">Sistem Rating Transparan</h5>
                            <p class="text-muted mb-0">Lihat track record dan rating pembawa barang sebelum Anda mempercayakan titipan Anda.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-5">
        <div class="container">
            <div class="bg-primary rounded-4 p-5 text-center text-white position-relative overflow-hidden" data-aos="zoom-in">
                <div class="position-relative z-1">
                    <h2 class="fw-bold mb-3">Siap Mempermudah Titipan Anda?</h2>
                    <p class="lead mb-4 opacity-75">Bergabunglah dengan ratusan mahasiswa lainnya yang sudah menggunakan TITIPIN.</p>
                    <a href="register.php" class="btn btn-light btn-lg fw-bold text-primary px-5 rounded-pill shadow">
                        Daftar Sekarang Gratis <i class="bi bi-arrow-right ms-2"></i>
                    </a>
                </div>
                <!-- Decorative circles -->
                <div class="position-absolute top-0 start-0 translate-middle rounded-circle bg-white opacity-10" style="width: 300px; height: 300px;"></div>
                <div class="position-absolute bottom-0 end-0 translate-middle-x rounded-circle bg-white opacity-10" style="width: 200px; height: 200px;"></div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4 mb-lg-0">
                    <h4 class="text-white fw-bold mb-3"><i class="bi bi-box-seam-fill me-2"></i>TITIPIN</h4>
                    <p class="small">Sistem Titip Barang Antar Mahasiswa yang aman, cepat, dan saling menguntungkan. "Titip Barang Jadi Lebih Mudah"</p>
                </div>
                <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                    <h6 class="text-white fw-bold mb-3">Menu</h6>
                    <ul class="list-unstyled small">
                        <li class="mb-2"><a href="index.php">Beranda</a></li>
                        <li class="mb-2"><a href="#cara-kerja">Cara Kerja</a></li>
                        <li class="mb-2"><a href="login.php">Login</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-4 mb-4 mb-md-0">
                    <h6 class="text-white fw-bold mb-3">Bantuan</h6>
                    <ul class="list-unstyled small">
                        <li class="mb-2"><a href="#">Syarat & Ketentuan</a></li>
                        <li class="mb-2"><a href="#">Kebijakan Privasi</a></li>
                        <li class="mb-2"><a href="#">Hubungi Kami</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-4">
                    <h6 class="text-white fw-bold mb-3">Kontak</h6>
                    <ul class="list-unstyled small">
                        <li class="mb-2"><i class="bi bi-envelope me-2"></i> admin@titipin.com</li>
                        <li class="mb-2"><i class="bi bi-geo-alt me-2"></i> Kampus Universitas</li>
                    </ul>
                </div>
            </div>
            <hr class="border-secondary my-4">
            <div class="text-center small">
                <p class="mb-0">&copy; 2026 TITIPIN. All rights reserved. Dibuat dengan <i class="bi bi-heart-fill text-danger"></i> untuk Mahasiswa.</p>
            </div>
        </div</div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- AOS Animation JS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    
    <script>
        // Inisialisasi Animasi AOS
        AOS.init({
            once: true, // Animasi hanya berjalan sekali saat scroll ke bawah
            offset: 100, // Trigger animasi 100px sebelum elemen terlihat
            duration: 800, // Durasi animasi
            easing: 'ease-out-cubic',
        });

        // Navbar shadow on scroll
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar-glass');
            if (window.scrollY > 50) {
                navbar.style.boxShadow = '0 4px 20px rgba(0,0,0,0.08)';
                navbar.style.background = 'rgba(255, 255, 255, 0.95)';
            } else {
                navbar.style.boxShadow = 'none';
                navbar.style.background = 'rgba(255, 255, 255, 0.85)';
            }
        });
    </script>
</body>
</html>