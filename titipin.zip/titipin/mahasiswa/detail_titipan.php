<?php
require_once '../config/database.php';
cekLogin();
cekRole('mahasiswa');

$user_id = $_SESSION['user_id'];
$id = (int)($_GET['id'] ?? 0);

// Handle batal
if (isset($_GET['batal'])) {
    $stmt = $pdo->prepare("UPDATE titipan SET status = 'Dibatalkan' WHERE id = ? AND pemilik_id = ? AND status = 'Menunggu'");
    $stmt->execute([$id, $user_id]);
    logAktivitas($pdo, $user_id, $id, "Membatalkan titipan");
    $_SESSION['success'] = 'Titipan berhasil dibatalkan.';
    header('Location: titipan_saya.php');
    exit;
}

// Handle konfirmasi selesai oleh pemilik
if (isset($_POST['konfirmasi_selesai'])) {
    $stmt = $pdo->prepare("UPDATE titipan SET status = 'Selesai' WHERE id = ? AND pemilik_id = ?");
    $stmt->execute([$id, $user_id]);
    logAktivitas($pdo, $user_id, $id, "Mengkonfirmasi titipan selesai");
    $_SESSION['success'] = 'Titipan berhasil diselesaikan!';
    header('Location: detail_titipan.php?id=' . $id);
    exit;
}

$stmt = $pdo->prepare("SELECT t.*, k.nama_kategori, 
                       p.nama as pemilik_nama, p.no_hp as pemilik_hp, p.email as pemilik_email,
                       b.nama as pembawa_nama, b.no_hp as pembawa_hp
                       FROM titipan t 
                       JOIN kategori k ON t.kategori_id = k.id 
                       JOIN users p ON t.pemilik_id = p.id 
                       LEFT JOIN users b ON t.pembawa_id = b.id 
                       WHERE t.id = ?");
$stmt->execute([$id]);
$t = $stmt->fetch();

if (!$t || ($t['pemilik_id'] != $user_id && $t['pembawa_id'] != $user_id)) {
    $_SESSION['error'] = 'Akses ditolak.';
    header('Location: titipan_saya.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Titipan - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'sidebar.php'; ?>
        <div class="flex-grow-1 bg-light">
            <nav class="navbar navbar-light bg-white shadow-sm px-4">
                <span class="navbar-text"><i class="bi bi-info-circle"></i> Detail Titipan</span>
            </nav>
            
            <div class="p-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-3">
                            <h5><?= e($t['kode_titipan']) ?></h5>
                            <span class="badge bg-<?= 
                                $t['status']=='Selesai'?'success':
                                ($t['status']=='Menunggu'?'warning':
                                ($t['status']=='Dibatalkan'?'danger':'info')) ?> fs-6">
                                <?= e($t['status']) ?>
                            </span>
                        </div>
                        
                        <table class="table">
                            <tr><th width="200">Nama Barang</th><td><?= e($t['nama_barang']) ?></td></tr>
                            <tr><th>Kategori</th><td><?= e($t['nama_kategori']) ?></td></tr>
                            <tr><th>Deskripsi</th><td><?= e($t['deskripsi'] ?? '-') ?></td></tr>
                            <tr><th>Jumlah</th><td><?= e($t['jumlah']) ?></td></tr>
                            <tr><th>Lokasi Pengambilan</th><td><?= e($t['lokasi_pengambilan']) ?></td></tr>
                            <tr><th>Lokasi Tujuan</th><td><?= e($t['lokasi_tujuan']) ?></td></tr>
                            <tr><th>Tanggal Pengambilan</th><td><?= formatTanggal($t['tanggal_pengambilan']) ?></td></tr>
                            <tr><th>Batas Pengantaran</th><td><?= formatTanggal($t['batas_pengantaran']) ?></td></tr>
                            <tr><th>Biaya Jasa</th><td><?= formatRupiah($t['biaya_jasa']) ?></td></tr>
                            <tr><th>Catatan</th><td><?= e($t['catatan'] ?? '-') ?></td></tr>
                            <tr><th>Pemilik Barang</th><td><?= e($t['pemilik_nama']) ?> (<?= e($t['pemilik_hp']) ?>)</td></tr>
                            <tr><th>Pembawa</th><td><?= e($t['pembawa_nama'] ?? 'Belum ada') ?></td></tr>
                        </table>
                        
                        <!-- Timeline Status -->
                        <h6 class="mt-4">Progress:</h6>
                        <div class="progress mb-3" style="height: 25px;">
                            <?php 
                            $progress = [
                                'Menunggu' => 15,
                                'Diterima' => 35,
                                'Barang Diambil' => 55,
                                'Dalam Perjalanan' => 75,
                                'Selesai' => 100,
                                'Dibatalkan' => 0
                            ];
                            $p = $progress[$t['status']] ?? 0;
                            ?>
                            <div class="progress-bar bg-success" role="progressbar" style="width: <?= $p ?>%">
                                <?= $p ?>%
                            </div>
                        </div>
                        
                        <a href="titipan_saya.php" class="btn btn-secondary">
                            <i class="bi bi-arrow-left"></i> Kembali
                        </a>
                        
                        <?php if ($t['status'] === 'Dalam Perjalanan' && $t['pemilik_id'] == $user_id): ?>
                            <form method="POST" class="d-inline">
                                <button type="submit" name="konfirmasi_selesai" class="btn btn-success"
                                        onclick="return confirm('Konfirmasi barang telah diterima?')">
                                    <i class="bi bi-check-circle"></i> Konfirmasi Barang Diterima
                                </button>
                            </form>
                        <?php endif; ?>
                        
                        <?php if ($t['status'] === 'Selesai' && $t['pemilik_id'] == $user_id): ?>
                            <a href="rating.php?id=<?= $t['id'] ?>" class="btn btn-warning">
                                <i class="bi bi-star"></i> Beri Rating
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>