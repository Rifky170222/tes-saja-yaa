<?php
require_once '../config/database.php';
cekLogin();
cekRole('mahasiswa');

$stmt = $pdo->query("SELECT * FROM kategori ORDER BY nama_kategori");
$kategori = $stmt->fetchAll();

$errors = [];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Titipan - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'sidebar.php'; ?>
        <div class="flex-grow-1 bg-light">
            <nav class="navbar navbar-light bg-white shadow-sm px-4">
                <span class="navbar-text"><i class="bi bi-plus-circle"></i> Buat Titipan</span>
                <div class="d-flex align-items-center">
                    <span class="fw-bold"><?= e($_SESSION['nama']) ?></span>
                </div>
            </nav>
            
            <div class="p-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="mb-4">Form Permintaan Titipan</h5>
                        
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php foreach ($errors as $err): ?>
                                        <li><?= e($err) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="simpan_titipan.php">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Nama Barang *</label>
                                    <input type="text" name="nama_barang" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Kategori Barang *</label>
                                    <select name="kategori_id" class="form-select" required>
                                        <option value="">-- Pilih Kategori --</option>
                                        <?php foreach ($kategori as $k): ?>
                                            <option value="<?= $k['id'] ?>"><?= e($k['nama_kategori']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Deskripsi Barang</label>
                                    <textarea name="deskripsi" class="form-control" rows="2"></textarea>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Jumlah Barang *</label>
                                    <input type="number" name="jumlah" class="form-control" min="1" value="1" required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Tanggal Pengambilan *</label>
                                    <input type="date" name="tanggal_pengambilan" class="form-control" required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Batas Waktu Pengantaran *</label>
                                    <input type="date" name="batas_pengantaran" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Lokasi Pengambilan *</label>
                                    <input type="text" name="lokasi_pengambilan" class="form-control" placeholder="Contoh: Kos A Jl. Merdeka No.1" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Lokasi Tujuan *</label>
                                    <input type="text" name="lokasi_tujuan" class="form-control" placeholder="Contoh: Kampus Gedung A" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Biaya Jasa Titip (Opsional)</label>
                                    <div class="input-group">
                                        <span class="input-group-text">Rp</span>
                                        <input type="number" name="biaya_jasa" class="form-control" min="0" value="0">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Catatan Tambahan</label>
                                    <textarea name="catatan" class="form-control" rows="2" placeholder="Contoh: Tolong hati-hati, barang pecah belah"></textarea>
                                </div>
                                <div class="col-12">
                                    <div class="form-check">
                                        <input type="checkbox" name="setuju" class="form-check-input" id="setuju" required>
                                        <label class="form-check-label" for="setuju">
                                            Barang tidak berbahaya dan bukan barang terlarang.
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-send"></i> Buat Permintaan Titipan
                                    </button>
                                    <a href="dashboard.php" class="btn btn-secondary">Batal</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>