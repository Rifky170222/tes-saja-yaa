<?php
require_once '../config/database.php';
cekLogin();
cekRole('mahasiswa');

$user_id = $_SESSION['user_id'];
$id = (int)($_GET['id'] ?? 0);

if ($id == 0) {
    header('Location: cari_titipan.php');
    exit;
}

$stmt = $pdo->prepare("SELECT t.*, u.nama as pemilik_nama, u.no_hp as pemilik_hp, k.nama_kategori 
                       FROM titipan t 
                       JOIN users u ON t.pemilik_id = u.id 
                       JOIN kategori k ON t.kategori_id = k.id 
                       WHERE t.id = ?");
$stmt->execute([$id]);
$titipan = $stmt->fetch();

if (!$titipan) {
    $_SESSION['error'] = 'Titipan tidak ditemukan.';
    header('Location: cari_titipan.php');
    exit;
}

// Tidak boleh ambil titipan sendiri
if ($titipan['pemilik_id'] == $user_id) {
    $_SESSION['error'] = 'Anda tidak bisa mengambil titipan Anda sendiri.';
    header('Location: cari_titipan.php');
    exit;
}

if ($titipan['status'] !== 'Menunggu') {
    $_SESSION['error'] = 'Titipan sudah tidak tersedia.';
    header('Location: cari_titipan.php');
    exit;
}

// Proses konfirmasi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['konfirmasi'])) {
    $stmt = $pdo->prepare("UPDATE titipan SET pembawa_id = ?, status = 'Diterima' WHERE id = ? AND status = 'Menunggu'");
    $stmt->execute([$user_id, $id]);
    
    logAktivitas($pdo, $user_id, $id, "Mengambil titipan {$titipan['kode_titipan']}");
    logAktivitas($pdo, $titipan['pemilik_id'], $id, "Titipan {$titipan['kode_titipan']} diambil oleh {$_SESSION['nama']}");
    
    $_SESSION['success'] = 'Titipan berhasil diambil!';
    header('Location: titipan_dibawa.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Ambil Titipan - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'sidebar.php'; ?>
        <div class="flex-grow-1 bg-light">
            <nav class="navbar navbar-light bg-white shadow-sm px-4">
                <span class="navbar-text"><i class="bi bi-check-circle"></i> Konfirmasi Ambil Titipan</span>
            </nav>
            
            <div class="p-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="mb-4">Konfirmasi Ambil Titipan</h5>
                        <p class="text-muted">Pastikan Anda benar-benar dapat mengambil dan mengantarkan barang ini.</p>
                        
                        <table class="table">
                            <tr>
                                <th width="200">Kode Titipan</th>
                                <td><?= e($titipan['kode_titipan']) ?></td>
                            </tr>
                            <tr>
                                <th>Barang</th>
                                <td><?= e($titipan['nama_barang']) ?> (<?= e($titipan['nama_kategori']) ?>)</td>
                            </tr>
                            <tr>
                                <th>Deskripsi</th>
                                <td><?= e($titipan['deskripsi']) ?></td>
                            </tr>
                            <tr>
                                <th>Jumlah</th>
                                <td><?= e($titipan['jumlah']) ?></td>
                            </tr>
                            <tr>
                                <th>Lokasi Pengambilan</th>
                                <td><?= e($titipan['lokasi_pengambilan']) ?></td>
                            </tr>
                            <tr>
                                <th>Lokasi Tujuan</th>
                                <td><?= e($titipan['lokasi_tujuan']) ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal Pengambilan</th>
                                <td><?= formatTanggal($titipan['tanggal_pengambilan']) ?></td>
                            </tr>
                            <tr>
                                <th>Batas Pengantaran</th>
                                <td><?= formatTanggal($titipan['batas_pengantaran']) ?></td>
                            </tr>
                            <tr>
                                <th>Biaya Jasa</th>
                                <td><?= formatRupiah($titipan['biaya_jasa']) ?></td>
                            </tr>
                            <tr>
                                <th>Pemilik Barang</th>
                                <td><?= e($titipan['pemilik_nama']) ?> (<?= e($titipan['pemilik_hp']) ?>)</td>
                            </tr>
                            <?php if (!empty($titipan['catatan'])): ?>
                            <tr>
                                <th>Catatan</th>
                                <td><?= e($titipan['catatan']) ?></td>
                            </tr>
                            <?php endif; ?>
                        </table>
                        
                        <form method="POST" class="mt-3">
                            <button type="submit" name="konfirmasi" class="btn btn-success" 
                                    onclick="return confirm('Yakin akan mengambil titipan ini?')">
                                <i class="bi bi-check-circle"></i> Konfirmasi Ambil Titipan
                            </button>
                            <a href="cari_titipan.php" class="btn btn-secondary">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>