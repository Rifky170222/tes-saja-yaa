<?php
require_once '../config/database.php';
cekLogin();
cekRole('mahasiswa');

$user_id = $_SESSION['user_id'];
$success = $error = '';

// Handle upload foto
$upload_dir = '../assets/img/';
if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $no_hp = trim($_POST['no_hp'] ?? '');
    $prodi = trim($_POST['prodi'] ?? '');
    $kelas = trim($_POST['kelas'] ?? '');
    $foto_lama = $_POST['foto_lama'] ?? 'default.jpg';
    
    $foto = $foto_lama;
    
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed) && $_FILES['foto']['size'] < 2000000) {
            $foto = 'user_' . $user_id . '_' . time() . '.' . $ext;
            move_uploaded_file($_FILES['foto']['tmp_name'], $upload_dir . $foto);
        } else {
            $error = 'File tidak valid. Gunakan JPG/PNG/GIF maksimal 2MB.';
        }
    }
    
    if (empty($error) && !empty($nama) && !empty($no_hp) && !empty($prodi) && !empty($kelas)) {
        $stmt = $pdo->prepare("UPDATE users SET nama = ?, no_hp = ?, prodi = ?, kelas = ?, foto = ? WHERE id = ?");
        $stmt->execute([$nama, $no_hp, $prodi, $kelas, $foto, $user_id]);
        
        $_SESSION['nama'] = $nama;
        $_SESSION['foto'] = $foto;
        logAktivitas($pdo, $user_id, null, 'Memperbarui profil');
        $success = 'Profil berhasil diupdate!';
    } elseif (empty($error)) {
        $error = 'Semua field wajib diisi.';
    }
}

// Ambil data user
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Jumlah titipan berhasil dibawa
$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM titipan WHERE pembawa_id = ? AND status = 'Selesai'");
$stmt->execute([$user_id]);
$total_bawa = $stmt->fetch()['total'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Profil - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'sidebar.php'; ?>
        <div class="flex-grow-1 bg-light">
            <nav class="navbar navbar-light bg-white shadow-sm px-4">
                <span class="navbar-text"><i class="bi bi-person"></i> Profil</span>
            </nav>
            
            <div class="p-4">
                <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
                <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
                
                <div class="row">
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm text-center">
                            <div class="card-body">
                                <img src="../assets/img/<?= e($user['foto']) ?>" class="rounded-circle mb-3" 
                                     width="150" height="150" style="object-fit: cover;">
                                <h5><?= e($user['nama']) ?></h5>
                                <p class="text-muted"><?= e($user['npm']) ?></p>
                                <hr>
                                <div class="mb-2">
                                    <h4 class="text-warning">
                                        <?php 
                                        $r = (float)$user['rating'];
                                        for ($i = 1; $i <= 5; $i++): ?>
                                            <i class="bi bi-star<?= $i <= round($r) ? '-fill' : '' ?>"></i>
                                        <?php endfor; ?>
                                    </h4>
                                    <small><?= number_format($r, 2) ?> / 5.00</small>
                                </div>
                                <p class="mb-0"><strong><?= $total_bawa ?></strong> titipan berhasil dibawa</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body">
                                <h5>Edit Profil</h5>
                                <form method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="foto_lama" value="<?= e($user['foto']) ?>">
                                    
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Nama Lengkap</label>
                                            <input type="text" name="nama" class="form-control" 
                                                   value="<?= e($user['nama']) ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">NPM</label>
                                            <input type="text" class="form-control" value="<?= e($user['npm']) ?>" disabled>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Email</label>
                                            <input type="email" class="form-control" value="<?= e($user['email']) ?>" disabled>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Nomor HP</label>
                                            <input type="text" name="no_hp" class="form-control" 
                                                   value="<?= e($user['no_hp']) ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Program Studi</label>
                                            <input type="text" name="prodi" class="form-control" 
                                                   value="<?= e($user['prodi']) ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Kelas</label>
                                            <input type="text" name="kelas" class="form-control" 
                                                   value="<?= e($user['kelas']) ?>" required>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">Foto Profil</label>
                                            <input type="file" name="foto" class="form-control" accept="image/*">
                                            <small class="text-muted">Maks 2MB (JPG, PNG, GIF)</small>
                                        </div>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary mt-3">
                                        <i class="bi bi-save"></i> Simpan Perubahan
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>