<?php
require_once '../config/database.php';
cekLogin();
cekRole('mahasiswa');

$user_id = $_SESSION['user_id'];

$status_filter = $_GET['status'] ?? '';
$where = "t.pemilik_id = ?";
$params = [$user_id];

if ($status_filter !== '') {
    $where .= " AND t.status = ?";
    $params[] = $status_filter;
}

$stmt = $pdo->prepare("SELECT t.*, k.nama_kategori, p.nama as pembawa_nama 
                       FROM titipan t 
                       JOIN kategori k ON t.kategori_id = k.id 
                       LEFT JOIN users p ON t.pembawa_id = p.id 
                       WHERE $where 
                       ORDER BY t.created_at DESC");
$stmt->execute($params);
$titipan = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Titipan Saya - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'sidebar.php'; ?>
        <div class="flex-grow-1 bg-light">
            <nav class="navbar navbar-light bg-white shadow-sm px-4">
                <span class="navbar-text"><i class="bi bi-box"></i> Titipan Saya</span>
            </nav>
            
            <div class="p-4">
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success"><?= e($_SESSION['success']) ?></div>
                    <?php unset($_SESSION['success']); ?>
                <?php endif; ?>
                
                <div class="mb-3">
                    <form method="GET" class="d-flex gap-2">
                        <select name="status" class="form-select w-auto">
                            <option value="">Semua Status</option>
                            <option value="Menunggu" <?= $status_filter=='Menunggu'?'selected':'' ?>>Menunggu</option>
                            <option value="Diterima" <?= $status_filter=='Diterima'?'selected':'' ?>>Diterima</option>
                            <option value="Barang Diambil" <?= $status_filter=='Barang Diambil'?'selected':'' ?>>Barang Diambil</option>
                            <option value="Dalam Perjalanan" <?= $status_filter=='Dalam Perjalanan'?'selected':'' ?>>Dalam Perjalanan</option>
                            <option value="Selesai" <?= $status_filter=='Selesai'?'selected':'' ?>>Selesai</option>
                            <option value="Dibatalkan" <?= $status_filter=='Dibatalkan'?'selected':'' ?>>Dibatalkan</option>
                        </select>
                        <button type="submit" class="btn btn-primary">Filter</button>
                    </form>
                </div>
                
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Kode</th>
                                        <th>Barang</th>
                                        <th>Tujuan</th>
                                        <th>Tanggal</th>
                                        <th>Pembawa</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($titipan)): ?>
                                        <tr><td colspan="7" class="text-center">Belum ada titipan.</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($titipan as $t): ?>
                                            <tr>
                                                <td><code><?= e($t['kode_titipan']) ?></code></td>
                                                <td><?= e($t['nama_barang']) ?></td>
                                                <td><?= e($t['lokasi_tujuan']) ?></td>
                                                <td><?= formatTanggal($t['tanggal_pengambilan']) ?></td>
                                                <td><?= e($t['pembawa_nama'] ?? 'Belum ada') ?></td>
                                                <td>
                                                    <span class="badge bg-<?= 
                                                        $t['status']=='Selesai'?'success':
                                                        ($t['status']=='Menunggu'?'warning':
                                                        ($t['status']=='Dibatalkan'?'danger':'info')) ?>">
                                                        <?= e($t['status']) ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="detail_titipan.php?id=<?= $t['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                        <i class="bi bi-eye"></i> Detail
                                                    </a>
                                                    <?php if ($t['status'] === 'Selesai'): ?>
                                                        <a href="rating.php?id=<?= $t['id'] ?>" class="btn btn-sm btn-outline-warning">
                                                            <i class="bi bi-star"></i> Rating
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if ($t['status'] === 'Menunggu'): ?>
                                                        <a href="detail_titipan.php?id=<?= $t['id'] ?>&batal=1" class="btn btn-sm btn-outline-danger"
                                                           onclick="return confirm('Batalkan titipan ini?')">
                                                            <i class="bi bi-x-circle"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>