<?php
require_once '../config/database.php';
cekLogin();
cekRole('mahasiswa');

$user_id = $_SESSION['user_id'];
$id = (int)($_GET['id'] ?? 0);

// Cek titipan
$stmt = $pdo->prepare("SELECT * FROM titipan WHERE id = ? AND pemilik_id = ? AND status = 'Selesai'");
$stmt->execute([$id, $user_id]);
$titipan = $stmt->fetch();

if (!$titipan) {
    $_SESSION['error'] = 'Titipan tidak valid atau belum selesai.';
    header('Location: titipan_saya.php');
    exit;
}

// Cek sudah pernah rating
$stmt = $pdo->prepare("SELECT * FROM rating WHERE titipan_id = ? AND pemberi_id = ?");
$stmt->execute([$id, $user_id]);
if ($stmt->fetch()) {
    $_SESSION['error'] = 'Anda sudah memberikan rating.';
    header('Location: titipan_saya.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = (int)($_POST['rating'] ?? 0);
    $komentar = trim($_POST['komentar'] ?? '');
    
    if ($rating < 1 || $rating > 5) {
        $error = 'Rating harus 1-5.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO rating (titipan_id, pemberi_id, penerima_id, rating, komentar) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$id, $user_id, $titipan['pembawa_id'], $rating, $komentar]);
            updateRatingUser($pdo, $titipan['pembawa_id']);
            logAktivitas($pdo, $user_id, $id, "Memberikan rating $rating bintang");
            $_SESSION['success'] = 'Terima kasih atas rating Anda!';
            header('Location: riwayat.php');
            exit;
        } catch (Exception $e) {
            $error = 'Gagal menyimpan rating.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Rating - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'sidebar.php'; ?>
        <div class="flex-grow-1 bg-light">
            <nav class="navbar navbar-light bg-white shadow-sm px-4">
                <span class="navbar-text"><i class="bi bi-star"></i> Beri Rating</span>
            </nav>
            
            <div class="p-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h5>Beri Rating untuk Pembawa Barang</h5>
                        <p class="text-muted">Kode: <?= e($titipan['kode_titipan']) ?> - <?= e($titipan['nama_barang']) ?></p>
                        
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?= e($error) ?></div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Rating (1-5 bintang)</label>
                                <div class="rating-stars">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <input type="radio" name="rating" value="<?= $i ?>" id="star<?= $i ?>" required>
                                        <label for="star<?= $i ?>">
                                            <i class="bi bi-star-fill" style="font-size: 2rem; cursor: pointer;"></i>
                                        </label>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Komentar (Opsional)</label>
                                <textarea name="komentar" class="form-control" rows="3" 
                                          placeholder="Contoh: Barang sampai dengan aman dan tepat waktu"></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-send"></i> Kirim Rating
                            </button>
                            <a href="titipan_saya.php" class="btn btn-secondary">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>