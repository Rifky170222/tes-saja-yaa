<?php
require_once '../config/database.php';
cekLogin();
cekRole('mahasiswa');

$user_id = $_SESSION['user_id'];

// Statistik
$stmt = $pdo->prepare("SELECT COUNT(*) FROM titipan WHERE pemilik_id = ?");
$stmt->execute([$user_id]);
$total_buat = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM titipan WHERE pemilik_id = ? AND status IN ('Menunggu', 'Diterima', 'Barang Diambil', 'Dalam Perjalanan')");
$stmt->execute([$user_id]);
$berjalan = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM titipan WHERE pemilik_id = ? AND status = 'Selesai'");
$stmt->execute([$user_id]);
$selesai = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM titipan WHERE pembawa_id = ?");
$stmt->execute([$user_id]);
$diterima = $stmt->fetchColumn();

// Titipan aktif yang dibawa
$stmt = $pdo->prepare("SELECT t.*, u.nama as pemilik_nama, k.nama_kategori 
                       FROM titipan t 
                       JOIN users u ON t.pemilik_id = u.id 
                       JOIN kategori k ON t.kategori_id = k.id 
                       WHERE t.pembawa_id = ? AND t.status IN ('Diterima', 'Barang Diambil', 'Dalam Perjalanan')
                       ORDER BY t.updated_at DESC LIMIT 5");
$stmt->execute([$user_id]);
$titipan_aktif = $stmt->fetchAll();

// Aktivitas terbaru
$stmt = $pdo->prepare("SELECT a.*, t.kode_titipan FROM aktivitas a 
                       LEFT JOIN titipan t ON a.titipan_id = t.id 
                       WHERE a.user_id = ? 
                       ORDER BY a.created_at DESC LIMIT 5");
$stmt->execute([$user_id]);
$aktivitas = $stmt->fetchAll();

// Greeting
$hour = date('H');
if ($hour < 12) $greeting = 'Selamat Pagi';
elseif ($hour < 17) $greeting = 'Selamat Siang';
elseif ($hour < 20) $greeting = 'Selamat Sore';
else $greeting = 'Selamat Malam';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <!-- Animated Background -->
    <div class="bg-blobs">
        <div class="blob blob-1"></div>
        <div class="blob blob-2"></div>
        <div class="blob blob-3"></div>
    </div>

    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Topbar -->
        <?php include 'topbar.php'; ?>
        
        <div class="content-wrapper">
            
            <!-- Welcome Banner -->
            <div class="welcome-banner fade-in-up">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <small class="opacity-75"><?= $greeting ?> 👋</small>
                        <h2 class="mt-1">Halo, <?= htmlspecialchars($_SESSION['nama']) ?>!</h2>
                        <p class="mb-3">Siap menitipkan atau membawa barang hari ini? Yuk cek aktivitas terbaru kamu.</p>
                        <div class="d-flex gap-2 flex-wrap">
                            <a href="buat_titipan.php" class="btn btn-light btn-sm fw-semibold">
                                <i class="bi bi-plus-circle me-1"></i> Buat Titipan Baru
                            </a>
                            <a href="cari_titipan.php" class="btn btn-outline-light btn-sm fw-semibold">
                                <i class="bi bi-search me-1"></i> Cari Titipan
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 d-none d-md-block text-end">
                        <img src="https://illustrations.popsy.co/amber/delivery.svg" alt="Illustration" class="welcome-illustration">
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="row g-3 mb-4">
                <div class="col-xl-3 col-md-6 fade-in-up stagger-1">
                    <div class="stat-card" style="--card-gradient: linear-gradient(135deg, #0d6efd, #6f42c1);">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Total Titipan</p>
                                <h3 class="stat-value counter" data-target="<?= $total_buat ?>">0</h3>
                                <span class="stat-trend up">
                                    <i class="bi bi-arrow-up"></i> Semua waktu
                                </span>
                            </div>
                            <div class="stat-icon">
                                <i class="bi bi-box-seam-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 fade-in-up stagger-2">
                    <div class="stat-card" style="--card-gradient: linear-gradient(135deg, #fd7e14, #ffc107);">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Sedang Berjalan</p>
                                <h3 class="stat-value counter" data-target="<?= $berjalan ?>">0</h3>
                                <span class="stat-trend up">
                                    <i class="bi bi-activity"></i> Aktif
                                </span>
                            </div>
                            <div class="stat-icon">
                                <i class="bi bi-truck"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 fade-in-up stagger-3">
                    <div class="stat-card" style="--card-gradient: linear-gradient(135deg, #20c997, #0dcaf0);">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Selesai</p>
                                <h3 class="stat-value counter" data-target="<?= $selesai ?>">0</h3>
                                <span class="stat-trend up">
                                    <i class="bi bi-check-circle"></i> Berhasil
                                </span>
                            </div>
                            <div class="stat-icon">
                                <i class="bi bi-check-circle-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 fade-in-up stagger-4">
                    <div class="stat-card" style="--card-gradient: linear-gradient(135deg, #6f42c1, #d63384);">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Titipan Dibawa</p>
                                <h3 class="stat-value counter" data-target="<?= $diterima ?>">0</h3>
                                <span class="stat-trend up">
                                    <i class="bi bi-person-check"></i> Anda bantu
                                </span>
                            </div>
                            <div class="stat-icon">
                                <i class="bi bi-person-check-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="row g-3 mb-4">
                <div class="col-12">
                    <h5 class="fw-bold mb-3 fade-in-up stagger-4">
                        <i class="bi bi-lightning-charge-fill text-warning"></i> Aksi Cepat
                    </h5>
                </div>
                <div class="col-md-3 col-6 fade-in-up stagger-1">
                    <a href="buat_titipan.php" class="quick-action">
                        <i class="bi bi-plus-circle text-primary"></i>
                        <span>Buat Titipan</span>
                    </a>
                </div>
                <div class="col-md-3 col-6 fade-in-up stagger-2">
                    <a href="cari_titipan.php" class="quick-action">
                        <i class="bi bi-search text-info"></i>
                        <span>Cari Titipan</span>
                    </a>
                </div>
                <div class="col-md-3 col-6 fade-in-up stagger-3">
                    <a href="titipan_saya.php" class="quick-action">
                        <i class="bi bi-box text-warning"></i>
                        <span>Lihat Titipan</span>
                    </a>
                </div>
                <div class="col-md-3 col-6 fade-in-up stagger-4">
                    <a href="profil.php" class="quick-action">
                        <i class="bi bi-person text-success"></i>
                        <span>Edit Profil</span>
                    </a>
                </div>
            </div>

            <!-- Main Content Grid -->
            <div class="row g-3">
                <!-- Titipan Aktif -->
                <div class="col-lg-8 fade-in-up stagger-3">
                    <div class="modern-card">
                        <div class="modern-card-header">
                            <h6><i class="bi bi-truck"></i> Titipan yang Anda Bawa</h6>
                            <a href="titipan_dibawa.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
                        </div>
                        <div class="modern-card-body">
                            <?php if (empty($titipan_aktif)): ?>
                                <div class="text-center py-4">
                                    <i class="bi bi-inbox" style="font-size: 3rem; color: #adb5bd;"></i>
                                    <p class="text-muted mt-2 mb-0">Belum ada titipan aktif yang Anda bawa</p>
                                    <a href="cari_titipan.php" class="btn btn-gradient btn-sm mt-3">Cari Titipan Sekarang</a>
                                </div>
                            <?php else: ?>
                                <?php 
                                $status_colors = [
                                    'Diterima' => '#0dcaf0',
                                    'Barang Diambil' => '#fd7e14',
                                    'Dalam Perjalanan' => '#6f42c1'
                                ];
                                foreach ($titipan_aktif as $t): 
                                    $status_color = $status_colors[$t['status']] ?? '#0d6efd';
                                ?>
                                    <div class="titipan-card" style="--status-color: <?= $status_color ?>;">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <div>
                                                <code class="small text-primary"><?= htmlspecialchars($t['kode_titipan']) ?></code>
                                                <h6 class="mb-1 mt-1 fw-bold"><?= htmlspecialchars($t['nama_barang']) ?></h6>
                                                <small class="text-muted">
                                                    <i class="bi bi-person"></i> <?= htmlspecialchars($t['pemilik_nama']) ?>
                                                    <span class="mx-2">•</span>
                                                    <i class="bi bi-tag"></i> <?= htmlspecialchars($t['nama_kategori']) ?>
                                                </small>
                                            </div>
                                            <span class="badge" style="background: <?= $status_color ?>20; color: <?= $status_color ?>;">
                                                <?= htmlspecialchars($t['status']) ?>
                                            </span>
                                        </div>
                                        <div class="d-flex gap-3 small text-muted mt-2">
                                            <span><i class="bi bi-geo-alt"></i> <?= htmlspecialchars($t['lokasi_pengambilan']) ?> → <?= htmlspecialchars($t['lokasi_tujuan']) ?></span>
                                        </div>
                                        <div class="mt-3">
                                            <a href="titipan_dibawa.php" class="btn btn-sm btn-gradient">
                                                <i class="bi bi-arrow-right"></i> Kelola Titipan
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Aktivitas Terbaru -->
                <div class="col-lg-4 fade-in-up stagger-4">
                    <div class="modern-card h-100">
                        <div class="modern-card-header">
                            <h6><i class="bi bi-clock-history"></i> Aktivitas Terbaru</h6>
                        </div>
                        <div class="modern-card-body">
                            <?php if (empty($aktivitas)): ?>
                                <div class="text-center py-4">
                                    <i class="bi bi-clock" style="font-size: 3rem; color: #adb5bd;"></i>
                                    <p class="text-muted mt-2 mb-0">Belum ada aktivitas</p>
                                </div>
                            <?php else: ?>
                                <div class="activity-timeline">
                                    <?php foreach ($aktivitas as $a): ?>
                                        <div class="activity-item">
                                            <div class="activity-dot"></div>
                                            <div class="activity-content">
                                                <h6><?= htmlspecialchars($a['aktivitas']) ?></h6>
                                                <small>
                                                    <i class="bi bi-clock"></i> 
                                                    <?= date('d M Y, H:i', strtotime($a['created_at'])) ?>
                                                </small>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <div class="text-center text-muted small mt-4 pb-3">
                <p class="mb-0">&copy; 2026 TITIPIN - Sistem Titip Barang Antar Mahasiswa</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Sidebar Toggle Mobile
        document.getElementById('sidebarToggle')?.addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
        });

        // Counter Animation
        document.querySelectorAll('.counter').forEach(counter => {
            const target = parseInt(counter.getAttribute('data-target'));
            const duration = 1500;
            const step = target / (duration / 16);
            let current = 0;
            
            const updateCounter = () => {
                current += step;
                if (current < target) {
                    counter.textContent = Math.ceil(current);
                    requestAnimationFrame(updateCounter);
                } else {
                    counter.textContent = target;
                }
            };
            
            // Start animation when visible
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        updateCounter();
                        observer.disconnect();
                    }
                });
            });
            observer.observe(counter);
        });
    </script>
</body>
</html>