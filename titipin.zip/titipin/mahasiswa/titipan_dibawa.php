<?php
require_once '../config/database.php';
cekLogin();
cekRole('mahasiswa');

$user_id = $_SESSION['user_id'];

// Proses update status
if (isset($_POST['update_status']) && isset($_POST['id']) && isset($_POST['status_baru'])) {
    $id = (int)$_POST['id'];
    $status_baru = $_POST['status_baru'];
    
    // Validasi status yang valid
    $valid_status = ['Barang Diambil', 'Dalam Perjalanan', 'Selesai'];
    if (in_array($status_baru, $valid_status)) {
        // Cek apakah titipan milik user
        $stmt = $pdo->prepare("SELECT pemilik_id FROM titipan WHERE id = ? AND pembawa_id = ?");
        $stmt->execute([$id, $user_id]);
        if ($stmt->fetch()) {
            $stmt = $pdo->prepare("UPDATE titipan SET status = ? WHERE id = ?");
            $stmt->execute([$status_baru, $id]);
            logAktivitas($pdo, $user_id, $id, "Mengubah status menjadi: $status_baru");
            $_SESSION['success'] = 'Status berhasil diupdate!';
        }
    }
    header('Location: titipan_dibawa.php');
    exit;
}

$stmt = $pdo->prepare("SELECT t.*, k.nama_kategori, u.nama as pemilik_nama, u.no_hp as pemilik_hp 
                       FROM titipan t 
                       JOIN kategori k ON t.kategori_id = k.id 
                       JOIN users u ON t.pemilik_id = u.id 
                       WHERE t.pembawa_id = ? AND t.status IN ('Diterima', 'Barang Diambil', 'Dalam Perjalanan')
                       ORDER BY t.updated_at DESC");
$stmt->execute([$user_id]);
$titipan = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Titipan Dibawa - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'sidebar.php'; ?>
        <div class="flex-grow-1 bg-light">
            <nav class="navbar navbar-light bg-white shadow-sm px-4">
                <span class="navbar-text"><i class="bi bi-truck"></i> Titipan yang Saya Bawa</span>
            </nav>
            
            <div class="p-4">
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success"><?= e($_SESSION['success']) ?></div>
                    <?php unset($_SESSION['success']); ?>
                <?php endif; ?>
                
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <?php if (empty($titipan)): ?>
                            <p class="text-center text-muted">Anda belum membawa titipan apapun.</p>
                        <?php else: ?>
                            <?php foreach ($titipan as $t): ?>
                                <div class="border rounded p-3 mb-3">
                                    <div class="d-flex justify-content-between mb-2">
                                        <div>
                                            <strong><?= e($t['kode_titipan']) ?></strong>
                                            <span class="badge bg-info ms-2"><?= e($t['status']) ?></span>
                                        </div>
                                        <small><?= formatTanggal($t['created_at']) ?></small>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p class="mb-1"><strong>Barang:</strong> <?= e($t['nama_barang']) ?></p>
                                            <p class="mb-1"><strong>Dari:</strong> <?= e($t['pemilik_nama']) ?> (<?= e($t['pemilik_hp']) ?>)</p>
                                            <p class="mb-1"><strong>Lokasi Ambil:</strong> <?= e($t['lokasi_pengambilan']) ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p class="mb-1"><strong>Kategori:</strong> <?= e($t['nama_kategori']) ?></p>
                                            <p class="mb-1"><strong>Jumlah:</strong> <?= e($t['jumlah']) ?></p>
                                            <p class="mb-1"><strong>Tujuan:</strong> <?= e($t['lokasi_tujuan']) ?></p>
                                        </div>
                                    </div>
                                    
                                    <!-- Status Action Buttons -->
                                    <div class="mt-3 d-flex gap-2 flex-wrap">
                                        <?php if ($t['status'] === 'Diterima'): ?>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="id" value="<?= $t['id'] ?>">
                                                <input type="hidden" name="status_baru" value="Barang Diambil">
                                                <button type="submit" name="update_status" class="btn btn-sm btn-warning">
                                                    <i class="bi bi-box"></i> Konfirmasi Barang Diambil
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <?php if ($t['status'] === 'Barang Diambil'): ?>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="id" value="<?= $t['id'] ?>">
                                                <input type="hidden" name="status_baru" value="Dalam Perjalanan">
                                                <button type="submit" name="update_status" class="btn btn-sm btn-info text-white">
                                                    <i class="bi bi-truck"></i> Dalam Perjalanan
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <?php if ($t['status'] === 'Dalam Perjalanan'): ?>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="id" value="<?= $t['id'] ?>">
                                                <input type="hidden" name="status_baru" value="Selesai">
                                                <button type="submit" name="update_status" class="btn btn-sm btn-success"
                                                        onclick="return confirm('Konfirmasi barang sudah sampai tujuan?')">
                                                    <i class="bi bi-check-circle"></i> Konfirmasi Selesai
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>