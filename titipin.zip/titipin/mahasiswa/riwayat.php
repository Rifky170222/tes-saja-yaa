<?php
require_once '../config/database.php';
cekLogin();
cekRole('mahasiswa');

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT t.*, k.nama_kategori, 
                       p.nama as pemilik_nama, b.nama as pembawa_nama,
                       r.rating, r.komentar
                       FROM titipan t 
                       JOIN kategori k ON t.kategori_id = k.id 
                       LEFT JOIN users p ON t.pemilik_id = p.id 
                       LEFT JOIN users b ON t.pembawa_id = b.id 
                       LEFT JOIN rating r ON r.titipan_id = t.id AND r.pemberi_id = ?
                       WHERE t.status IN ('Selesai', 'Dibatalkan') AND (t.pemilik_id = ? OR t.pembawa_id = ?)
                       ORDER BY t.updated_at DESC");
$stmt->execute([$user_id, $user_id, $user_id]);
$riwayat = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Riwayat - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'sidebar.php'; ?>
        <div class="flex-grow-1 bg-light">
            <nav class="navbar navbar-light bg-white shadow-sm px-4">
                <span class="navbar-text"><i class="bi bi-clock-history"></i> Riwayat</span>
            </nav>
            
            <div class="p-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Kode</th>
                                        <th>Barang</th>
                                        <th>Peran</th>
                                        <th>Tanggal</th>
                                        <th>Status</th>
                                        <th>Rating</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($riwayat)): ?>
                                        <tr><td colspan="6" class="text-center">Belum ada riwayat.</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($riwayat as $r): ?>
                                            <tr>
                                                <td><code><?= e($r['kode_titipan']) ?></code></td>
                                                <td><?= e($r['nama_barang']) ?></td>
                                                <td>
                                                    <?php if ($r['pemilik_id'] == $user_id): ?>
                                                        <span class="badge bg-primary">Pemilik</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-info">Pembawa</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?= formatTanggal($r['tanggal_pengambilan']) ?></td>
                                                <td>
                                                    <span class="badge bg-<?= $r['status']=='Selesai'?'success':'danger' ?>">
                                                        <?= e($r['status']) ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if ($r['rating']): ?>
                                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                                            <i class="bi bi-star<?= $i <= $r['rating'] ? '-fill text-warning' : '' ?>"></i>
                                                        <?php endfor; ?>
                                                    <?php else: ?>
                                                        <small class="text-muted">-</small>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>