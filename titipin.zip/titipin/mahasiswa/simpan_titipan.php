<?php
require_once '../config/database.php';
cekLogin();
cekRole('mahasiswa');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: buat_titipan.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$nama_barang = trim($_POST['nama_barang'] ?? '');
$kategori_id = (int)($_POST['kategori_id'] ?? 0);
$deskripsi = trim($_POST['deskripsi'] ?? '');
$jumlah = (int)($_POST['jumlah'] ?? 1);
$lokasi_pengambilan = trim($_POST['lokasi_pengambilan'] ?? '');
$lokasi_tujuan = trim($_POST['lokasi_tujuan'] ?? '');
$tanggal_pengambilan = $_POST['tanggal_pengambilan'] ?? '';
$batas_pengantaran = $_POST['batas_pengantaran'] ?? '';
$biaya_jasa = (float)($_POST['biaya_jasa'] ?? 0);
$catatan = trim($_POST['catatan'] ?? '');
$setuju = isset($_POST['setuju']);

// Validasi
if (empty($nama_barang) || $kategori_id == 0 || empty($lokasi_pengambilan) || empty($lokasi_tujuan) || empty($tanggal_pengambilan) || empty($batas_pengantaran)) {
    $_SESSION['error'] = 'Semua field wajib diisi.';
    header('Location: buat_titipan.php');
    exit;
}

if (!$setuju) {
    $_SESSION['error'] = 'Anda harus menyetujui bahwa barang tidak berbahaya.';
    header('Location: buat_titipan.php');
    exit;
}

$kode = generateKodeTitipan($pdo);

try {
    $stmt = $pdo->prepare("INSERT INTO titipan (kode_titipan, pemilik_id, kategori_id, nama_barang, deskripsi, jumlah, lokasi_pengambilan, lokasi_tujuan, tanggal_pengambilan, batas_pengantaran, biaya_jasa, catatan, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Menunggu')");
    $stmt->execute([$kode, $user_id, $kategori_id, $nama_barang, $deskripsi, $jumlah, $lokasi_pengambilan, $lokasi_tujuan, $tanggal_pengambilan, $batas_pengantaran, $biaya_jasa, $catatan]);
    
    $titipan_id = $pdo->lastInsertId();
    logAktivitas($pdo, $user_id, $titipan_id, "Membuat permintaan titipan $kode");
    
    $_SESSION['success'] = "Titipan berhasil dibuat dengan kode: $kode";
    header('Location: titipan_saya.php');
    exit;
} catch (Exception $e) {
    $_SESSION['error'] = 'Gagal membuat titipan: ' . $e->getMessage();
    header('Location: buat_titipan.php');
    exit;
}
?>