<?php
require_once '../config/database.php';
cekLogin();
cekRole('mahasiswa');

$user_id = $_SESSION['user_id'];

// Filter
$search = trim($_GET['search'] ?? '');
$kategori_filter = (int)($_GET['kategori'] ?? 0);
$tanggal_filter = $_GET['tanggal'] ?? '';

// Build query
$where = ["t.pemilik_id != ?", "t.status = 'Menunggu'"];
$params = [$user_id];

if (!empty($search)) {
    $where[] = "(t.lokasi_pengambilan LIKE ? OR t.lokasi_tujuan LIKE ? OR t.nama_barang LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

if ($kategori_filter > 0) {
    $where[] = "t.kategori_id = ?";
    $params[] = $kategori_filter;
}

if (!empty($tanggal_filter)) {
    $where[] = "t.tanggal_pengambilan = ?";
    $params[] = $tanggal_filter;
}

$sql = "SELECT t.*, u.nama as pemilik_nama, k.nama_kategori FROM titipan t 
        JOIN users u ON t.pemilik_id = u.id 
        JOIN kategori k ON t.kategori_id = k.id 
        WHERE " . implode(' AND ', $where) . " 
        ORDER BY t.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$titipan = $stmt->fetchAll();

// Kategori untuk filter
$stmt = $pdo->query("SELECT * FROM kategori");
$kategoris = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cari Titipan - TITIPIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'sidebar.php'; ?>
        <div class="flex-grow-1 bg-light">
            <nav class="navbar navbar-light bg-white shadow-sm px-4">
                <span class="navbar-text"><i class="bi bi-search"></i> Cari Titipan</span>
                <div class="d-flex align-items-center">
                    <span class="fw-bold"><?= e($_SESSION['nama']) ?></span>
                </div>
            </nav>
            
            <div class="p-4">
                <!-- Form Filter -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Cari (Lokasi/Barang)</label>
                                <input type="text" name="search" class="form-control" 
                                       value="<?= e($search) ?>" placeholder="Contoh: kampus">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Kategori</label>
                                <select name="kategori" class="form-select">
                                    <option value="0">Semua Kategori</option>
                                    <?php foreach ($kategoris as $k): ?>
                                        <option value="<?= $k['id'] ?>" <?= $kategori_filter==$k['id']?'selected':'' ?>>
                                            <?= e($k['nama_kategori']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Tanggal</label>
                                <input type="date" name="tanggal" class="form-control" 
                                       value="<?= e($tanggal_filter) ?>">
                            </div>
                            <div class="col-md-2 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="bi bi-search"></i> Cari
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Daftar Titipan -->
                <?php if (empty($titipan)): ?>
                    <div class="alert alert-info">Tidak ada titipan yang tersedia saat ini.</div>
                <?php else: ?>
                    <div class="row g-3">
                        <?php foreach ($titipan as $t): ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="card border-0 shadow-sm h-100">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between mb-2">
                                            <span class="badge bg-primary"><?= e($t['kode_titipan']) ?></span>
                                            <span class="badge bg-warning">Menunggu</span>
                                        </div>
                                        <h6 class="card-title"><?= e($t['nama_barang']) ?></h6>
                                        <p class="text-muted small mb-1">
                                            <i class="bi bi-tag"></i> <?= e($t['nama_kategori']) ?>
                                        </p>
                                        <p class="small mb-1">
                                            <i class="bi bi-person"></i> <?= e($t['pemilik_nama']) ?>
                                        </p>
                                        <p class="small mb-1">
                                            <i class="bi bi-geo-alt"></i> <?= e($t['lokasi_pengambilan']) ?> → <?= e($t['lokasi_tujuan']) ?>
                                        </p>
                                        <p class="small mb-1">
                                            <i class="bi bi-calendar"></i> <?= formatTanggal($t['tanggal_pengambilan']) ?>
                                        </p>
                                        <p class="small mb-2">
                                            <i class="bi bi-cash"></i> <?= formatRupiah($t['biaya_jasa']) ?>
                                        </p>
                                        <a href="ambil_titipan.php?id=<?= $t['id'] ?>" class="btn btn-success btn-sm w-100">
                                            <i class="bi bi-check-circle"></i> Saya Bisa Membawa
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>