<?php
// Hitung notifikasi (titipan yang perlu direspon)
$notif_count = 0;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM titipan WHERE pembawa_id = ? AND status IN ('Diterima', 'Barang Diambil', 'Dalam Perjalanan')");
    $stmt->execute([$_SESSION['user_id']]);
    $notif_count = $stmt->fetchColumn();
}

// Greeting berdasarkan waktu
$hour = date('H');
if ($hour < 12) $greeting = 'Selamat Pagi';
elseif ($hour < 17) $greeting = 'Selamat Siang';
elseif ($hour < 20) $greeting = 'Selamat Sore';
else $greeting = 'Selamat Malam';
?>

<div class="topbar-modern">
    <!-- Mobile Toggle -->
    <button class="topbar-icon-btn d-lg-none me-2" id="sidebarToggle">
        <i class="bi bi-list"></i>
    </button>
    
    <!-- Search -->
    <div class="topbar-search d-none d-md-block">
        <i class="bi bi-search"></i>
        <input type="text" placeholder="Cari titipan, barang, atau lokasi...">
    </div>
    
    <!-- Actions -->
    <div class="topbar-actions">
        <!-- Theme Toggle -->
        <button class="topbar-icon-btn d-none d-md-flex" title="Mode Tampilan">
            <i class="bi bi-moon-stars"></i>
        </button>
        
        <!-- Notifications -->
        <div class="dropdown">
            <button class="topbar-icon-btn" data-bs-toggle="dropdown">
                <i class="bi bi-bell"></i>
                <?php if ($notif_count > 0): ?>
                    <span class="notification-badge"><?= $notif_count ?></span>
                <?php endif; ?>
            </button>
            <div class="dropdown-menu dropdown-menu-end dropdown-menu-modern">
                <div class="px-3 py-2 border-bottom">
                    <h6 class="mb-0 fw-bold">Notifikasi</h6>
                </div>
                <div style="max-height: 300px; overflow-y: auto;">
                    <?php if ($notif_count > 0): ?>
                        <a href="titipan_dibawa.php" class="dropdown-item-modern">
                            <div style="width: 36px; height: 36px; border-radius: 10px; background: rgba(13,110,253,0.1); display: flex; align-items: center; justify-content: center;">
                                <i class="bi bi-truck text-primary"></i>
                            </div>
                            <div>
                                <div class="fw-semibold small">Anda memiliki <?= $notif_count ?> titipan aktif</div>
                                <small class="text-muted">Perlu ditindaklanjuti</small>
                            </div>
                        </a>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-bell-slash" style="font-size: 2rem;"></i>
                            <p class="mb-0 small mt-2">Tidak ada notifikasi baru</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- User Dropdown -->
        <div class="dropdown">
            <div class="topbar-user" data-bs-toggle="dropdown">
                <img src="../assets/img/<?= htmlspecialchars($_SESSION['foto'] ?? 'default.jpg') ?>" alt="User">
                <div class="topbar-user-info d-none d-md-block">
                    <h6><?= htmlspecialchars($_SESSION['nama'] ?? 'User') ?></h6>
                    <small><?= $greeting ?> 👋</small>
                </div>
                <i class="bi bi-chevron-down small text-muted"></i>
            </div>
            <div class="dropdown-menu dropdown-menu-end dropdown-menu-modern">
                <a href="profil.php" class="dropdown-item-modern">
                    <i class="bi bi-person text-primary"></i>
                    <div>
                        <div class="fw-semibold small">Profil Saya</div>
                        <small class="text-muted">Kelola akun Anda</small>
                    </div>
                </a>
                <a href="riwayat.php" class="dropdown-item-modern">
                    <i class="bi bi-clock-history text-info"></i>
                    <div>
                        <div class="fw-semibold small">Riwayat</div>
                        <small class="text-muted">Lihat transaksi</small>
                    </div>
                </a>
                <hr class="my-1">
                <a href="../logout.php" class="dropdown-item-modern text-danger" onclick="return confirm('Yakin logout?')">
                    <i class="bi bi-box-arrow-right"></i>
                    <div>
                        <div class="fw-semibold small">Logout</div>
                        <small class="text-muted">Keluar dari akun</small>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>