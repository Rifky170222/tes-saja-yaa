<aside class="sidebar bg-dark text-white p-3" style="width: 260px; min-height: 100vh;">
    <div class="text-center mb-4">
        <h5 class="fw-bold text-warning mb-1">
            <i class="bi bi-box-seam"></i> TITIPIN
        </h5>
        <small class="text-muted">Antar Mahasiswa</small>
    </div>
    
    <nav>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="buat_titipan.php">
                    <i class="bi bi-plus-circle"></i> Buat Titipan
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="cari_titipan.php">
                    <i class="bi bi-search"></i> Cari Titipan
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="titipan_saya.php">
                    <i class="bi bi-box"></i> Titipan Saya
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="titipan_dibawa.php">
                    <i class="bi bi-truck"></i> Titipan Dibawa
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="riwayat.php">
                    <i class="bi bi-clock-history"></i> Riwayat
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="profil.php">
                    <i class="bi bi-person"></i> Profil
                </a>
            </li>
            <li class="nav-item mt-3">
                <a class="nav-link text-white" href="../logout.php" onclick="return confirm('Yakin logout?')">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </li>
        </ul>
    </nav>
</aside>